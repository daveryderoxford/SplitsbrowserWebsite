/*
 *    SplitsBrowser - SplistGraph class.
 *
 *    Copyright (C) 2000  Dave Ryder
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this library; see the file COPYING.  If not, write to
 *    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 *    Boston, MA 02111-1307, USA.
 */

package orienteering.splitsbrowser;     

import java.lang.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

public class SplitsGraph extends Panel
{
  public static final int GRAPH_TYPE_COMPARISON = 0;
  public static final int GRAPH_TYPE_RACE = 1;
  private static final int GRAPH_TYPE_MAX = 2;

  public SplitsGraph()
  {
    super();
    this.setFont(new Font("SansSerif", 0, 10));

    enableEvents(AWTEvent.MOUSE_MOTION_EVENT_MASK);

    addComponentListener(
      new ComponentAdapter() {
        public void componentResized() {
          invalidateDimensions();
        }
      }
    );
  }

  public void setColor1(java.awt.Color newColor1)
  {
    if (color1 != newColor1) {
      color1 = newColor1;
      repaint();
    }
  }

  public Color getColor1()
  {
    return color1;
  }

  public void setColor2(Color newColor2)
  {
    if (color2 != newColor2) {
      color2 = newColor2;
      repaint();
    }
  }

  public Color getColor2()
  {
    return color2;
  }

  public Color getGridColor()
  {
    return gridColor;
  }

  public void setGridColor(Color newColor)
  {
    gridColor = newColor;
    repaint();
  }

  public void setCourse(Course newCourse)
  {
    course = newCourse;

    /* Remove all the displayed result */
    displayedResults.removeAllElements();
    displayColors.removeAllElements();

    /* Create an array to hold the X positions */
    if (newCourse != null) {
      xPos = new int[course.getNumSplits()+1];
    }

    invalidateDimensions();
  }

  public void invalidateDimensions() {
    computeDimensions = true;
    repaint();
  }

  public void setShowSplits(boolean newShowSplits) {
    showSplits = newShowSplits;
    repaint();
  }

  public Course getCourse()
  {
    return course;
  }

  public void displayResult(Result newResult)
  {
    /* Insert the result into the vector based on total time */
    Color colors[] = {Color.blue,
                      Color.red,
                      Color.black,
                      Color.green,
                      Color.magenta,
                      Color.pink,
                      Color.darkGray };

    displayedResults.addElement(newResult);
    int colorIndex = newResult.getPosition() % colors.length;

     displayColors.addElement( new Color(colors[colorIndex].getRGB() ) );

    invalidateDimensions();
  }

  public void removeResult(Result aResult)
  {
    /* Hide the result and repaint the screen */
    int index = displayedResults.indexOf(aResult);

    if (index != -1 ) {
      displayedResults.removeElementAt(index);
      displayColors.removeElementAt(index);

      invalidateDimensions();
    }
  }

  public boolean isDisplayed(Result aResult)
  {
    int index = displayedResults.indexOf(aResult);
    return (index != -1);
  }

  public void update(Graphics g)
  {
    paint(g);
  }

  public void paint(Graphics g)
  {
     if (course == null)
     {
       Dimension dim = this.getSize();
       g.setColor( this.getParent().getBackground() );
       g.fillRect(0, 0, dim.width, dim.height);
       return;
     }

    // set the physical graph dimensions
    xAxis.setMinPixel( LEFT_MARGIN + getAxisWidth(g, LEFT_AXIS) );
    xAxis.setMaxPixel( getSize().width -
                       RIGHT_MARGIN -
                       getAxisWidth(g, RIGHT_AXIS) );

    yAxis.setMinPixel(TOP_MARGIN);
    yAxis.setMaxPixel(getSize().height - BOTTOM_MARGIN);

    /* .. and the coordinate dimensions */
    if (computeDimensions)
    {
       computeGraphDimensions(g);
    }

    /* Compute the X positions for the controls */
    xPos[0] = xAxis.toPixel( 0);
    for (int i=0; i<course.getNumSplits(); i++)
    {
      xPos[i+1] = xAxis.toPixel( course.getWinner().getElaspsed(i) );
    }

    drawOffscreenImage();
    g.drawImage(offscreenBuffer, 0, 0, null);
  }

  protected void drawOffscreenImage()
  {
    Dimension dim = getSize();

    offscreenBuffer = createImage(dim.width, dim.height );

    Graphics g = offscreenBuffer.getGraphics();

    FontMetrics fontMetrics;
    fontMetrics = g.getFontMetrics(g.getFont());
    int halfFontHeight = fontMetrics.getHeight() / 2;
    int textGap = 2;

    /* Paint the background */
    paintBackground(g);

    /* Draw the results */

    for (int i=0; i< displayedResults.size(); i++)
    {
      /* Set the line style */
      g.setColor( (Color) displayColors.elementAt(i) );

      Result result = (Result) displayedResults.elementAt(i);
      int yOld = yAxis.toPixel( getYFirst(result) );
      int xOld = xPos[0];

      for (int splitCount=0; splitCount<course.getNumSplits(); splitCount++)
      {
        int y = yAxis.toPixel( getYSecs(result, splitCount) );

        // Draw three lines to make a thick one
        g.drawLine(xOld,   yOld,   xPos[splitCount+1],   y );
        g.drawLine(xOld,   yOld+1, xPos[splitCount+1],   y+1 );
        g.drawLine(xOld+1, yOld,   xPos[splitCount+1]+1, y );
        yOld = y;
        xOld = xPos[splitCount+1];
      }

      // Add text on the right of the graph
      g.setColor( getForeground() );

      int xright = xAxis.getMaxPixel();

      int ns = course.getNumSplits() - 1;
      int y = yAxis.toPixel( getYSecs(result, ns) ) + halfFontHeight;
      g.drawString(getRightText(result), xright, y );

      if (graphType == GRAPH_TYPE_RACE) {
        y = yAxis.toPixel( getYFirst(result) );
        g.drawString(getLeftText(result), LEFT_MARGIN, y);
      }

    }

    /* Draw a box around the graph */
    g.setColor(gridColor);

    g.draw3DRect(xAxis.getMinPixel(),
                 yAxis.getMinPixel(),
                 xAxis.getMaxPixel() - xAxis.getMinPixel(),
                 yAxis.getMaxPixel() - yAxis.getMinPixel(),
                 false );

    // Draw the axis labels
    g.setColor(getForeground());

    // Control numbers at the top
    int y = yAxis.getMinPixel() - 5;
    for (int i=0; i < course.getNumControls()-1; i++)
    {
      g.drawString(new Integer(i+1).toString(), xPos[i+1], y);
    }

    // Annotate the last label
    int i = course.getNumControls()-1;
    String s = new Integer(i+1).toString() + " control";
    g.drawString(s, xPos[i+1], y);

    // ...and the time at the bottom of the graph
    y = yAxis.getMaxPixel() + fontMetrics.getHeight();
    for (i=0; i< xAxis.getNumLabels()-1; i++)
    {
      g.drawString(xAxis.getLabelString(i), xAxis.getLabelPixel(i), y);
    }

    i = xAxis.getNumLabels()-1;
    g.drawString(xAxis.getLabelString(i) + " time (mins)",
                 xAxis.getLabelPixel(i),
                 y);

    // time on the left axis
    int x = xAxis.getMinPixel() - fontMetrics.stringWidth("88");

    for (i=0; i< yAxis.getNumLabels(); i++)
    {
      g.drawString(yAxis.getLabelString(i), x, yAxis.getLabelPixel(i) + halfFontHeight);
    }

  }

  private void paintBackground(Graphics g)
  {

     /* First paint the whole region background color */
     Dimension dim = this.getSize();
     g.setColor( this.getBackground() );
     g.draw3DRect(1, 1, dim.width-2, dim.height-2, false);

     /* Draw coloured stripes for each control */
     boolean useColor1 = true;
     for (int i=1; i < course.getNumSplits()+1; i++)
     {
         if (useColor1)
         {
           g.setColor(color1);
         }
         else
         {
           g.setColor(color2);
         }

         g.fillRect(xPos[i-1],
                    yAxis.getMinPixel(),
                    xPos[i] - xPos[i-1],
                    yAxis.getMaxPixel() - yAxis.getMinPixel() );

         useColor1 = !useColor1;
     }

     g.setColor(gridColor);

     /* Draw a horizontal grid */
     int x0 = xAxis.getMinPixel();
     int x1 = xAxis.getMaxPixel();

     for (int i=0; i< yAxis.getNumLabels(); i++)
     {
       g.drawLine(x0, yAxis.getLabelPixel(i), x1, yAxis.getLabelPixel(i));
     }

    // Paint selected split
    if ( (selectedSplit != -1) && showSplits ) {
      int w =3;
      g.setColor(gridColor);

      // Draw line at split
      g.fillRect(xPos[selectedSplit+1]-w,
                yAxis.getMinPixel(),
                w,
                yAxis.getMaxPixel() - yAxis.getMinPixel() );
     }
  }

  protected int getYFirst(Result result)
  {
    if (graphType == GRAPH_TYPE_COMPARISON)
    {
      return( 0 );
    }
    else
    {
      return( result.getStartTime().asSeconds() );
    }
  }

  protected int getYSecs(Result result, int split)
  {
    int secs;
    if (graphType == GRAPH_TYPE_COMPARISON) {
       secs = result.getElaspsed(split).asSeconds() -
                     course.getCumulativeOptimumTime(split).asSeconds();
    } else {
      secs = result.getActualTime(split).asSeconds();
    }

    return(secs);
  }

  protected String getRightText(Result result)
  {
    if ( (selectedSplit != -1) && showSplits) {
       return("   " + result.getFullName() + "  " + result.getTotalTime().toString(true) +
              "   " + result.getSplit(selectedSplit).toString(true));
    } else {
       return("   " + result.getFullName() + "  " + result.getTotalTime().toString(true) );
    }
  }

  protected String getLeftText(Result result)
  {
    if (graphType == GRAPH_TYPE_COMPARISON) {
      return("");
    } else {
      return( result.getFullName() + " " );
    }
  }

  protected void computeGraphDimensions(Graphics g)
  {
    /* Compute the logical (time) limits */

    /* Y axis limits */
      int maxTime;
      int minTime;

    if (displayedResults.size() == 0 )
    {
      minTime = 0;
      maxTime = 1;
    } else {

      maxTime = Integer.MIN_VALUE;
      minTime = Integer.MAX_VALUE;

      for (int i=0; i<displayedResults.size(); i++)
      {
        Result result = (Result) displayedResults.elementAt(i);

        int time;

        /* Handle first point */
        time = getYFirst(result);
        maxTime = Math.max(maxTime, time);
        minTime = Math.min(minTime, time);

        for (int splitCount=0; splitCount<course.getNumSplits(); splitCount++)
        {
          time = getYSecs(result, splitCount);

          maxTime = Math.max(maxTime, time);
          minTime = Math.min(minTime, time);
        }
      }
    }

    yAxis.setMaxTime( new Time(maxTime) );
    yAxis.setMinTime( new Time(minTime) );

    /* X axis limits */

    xAxis.setMinTime( Time.ZERO_TIME );
    xAxis.setMaxTime( course.getWinner().getTotalTime() );

    computeDimensions = false;
  }

  public void setGraphType(int newGraphType) throws Exception
  {
    if (newGraphType >= GRAPH_TYPE_MAX)
    {
      throw new Exception("Invalid graph type");
    }

    if (graphType != newGraphType)
    {
      graphType = newGraphType;
      computeDimensions = true;
      repaint();
    }
  }

  public int getGraphType()
  {
    return graphType;
  }

  protected int getAxisWidth(Graphics g, int axis)
  {
     int MARGIN_WIDTH = 3;
     int MAX_TEXT_WIDTH = 300;

    /* Computes the areas on the canvas that the text and graph occupy */
      FontMetrics fontMetrics;
      fontMetrics = g.getFontMetrics(g.getFont());

      Enumeration e;
      e = displayedResults.elements();

      int maxTextWidth = 0;
      while (e.hasMoreElements() )
      {
        Result result = (Result) e.nextElement();

        String s;
        if (axis == LEFT_AXIS) {
          s = getLeftText(result);
        } else {
          s = getRightText(result);
        }

        maxTextWidth = Math.max(maxTextWidth,
                                fontMetrics.stringWidth(s) );
      }

     return(Math.min(maxTextWidth, MAX_TEXT_WIDTH) );
  }

  protected void processMouseMotionEvent(MouseEvent e) {

    if (course != null) {
      int mouseX = e.getX();

      for (int xIndex=1; xIndex<course.getNumSplits()+1; xIndex++) {
         if ( (mouseX > xPos[xIndex-1]) &&  (mouseX <= xPos[xIndex] ) ) {
            if (xIndex-1 != selectedSplit) {
              // Note that the x positions are H 1 from the splits
              selectedSplit = xIndex-1;
              // This is very crude but seems to work OK
              repaint();
           }
           break;
         }
      }
    }
    super.processMouseMotionEvent(e);
  }

  // Class global varaibles
  private Image offscreenBuffer;

  private Color color1    = new Color(216, 220, 255);
  private Color color2    = new Color(203, 245, 255);
  private Color gridColor = Color.white;

  private Course course = null;
  private Vector displayedResults = new Vector();

  private Axis xAxis = new Axis(false);
  private Axis yAxis = new Axis(false);

  private boolean computeDimensions = true;
  private int[] xPos = null;
  private int graphType = GRAPH_TYPE_COMPARISON;

  private final int LEFT_MARGIN = 20;
  private final int RIGHT_MARGIN = 10;
  private final int TOP_MARGIN = 25;
  private final int BOTTOM_MARGIN = 30;

  private int LEFT_AXIS = 0;
  private int RIGHT_AXIS = 1;

  private Vector displayColors = new Vector();
  private int selectedSplit = -1;
  private boolean showSplits = true;

}

