/*
 *    SplitsBrowser - Result class.
 *
 *    Copyright (C) 2000  Dave Ryder
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this library; see the file COPYING.  If not, write to
 *    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 *    Boston, MA 02111-1307, USA.
 */

package orienteering.splitsbrowser;

import java.lang.*;
import java.util.*;
import java.awt.event.*;

public class Result extends Object
{

  public Result(Course newCourse,
                Time newStartTime,
                Time[] splits)
  {
    course       = newCourse;
    splitTimes   = splits;
    startTime    = newStartTime;
    elaspedTimes = null;
    course.addResult(this);
  }

  public Result(String newFirstName,
                String newSurname,
                String newClub,
                Course newCourse,
                Time newStartTime,
                Time[] splits)
  {
    this(newCourse, newStartTime, splits);
    setFirstName(newFirstName);
    setSurname(newSurname);
    setClub(newClub);
  }

  public void setFirstName(String newFirstName)
  {
    firstName = newFirstName;
    fullName = firstName + " " + surname;
  }

  public String getFirstName()
  {
    return firstName;
  }

  public void setSurname(String newSurname)
  {
    surname = newSurname;
    fullName = firstName + " " + surname;
  }

  public String getSurname()
  {
    return surname;
  }

  public void setClub(String newClub)
  {
    club = newClub;
  }

  public String getClub()
  {
    return club;
  }

  public Time getTotalTime()
  {
    return getElaspsed( course.getNumSplits()-1 );
  }

  public Time getSplit(int i)
  {
    return splitTimes[i];
  }

  public Time getElaspsed(int i)
  {
     if (elaspedTimes == null)
     {
       /* Create array for the elapsed times */
       elaspedTimes = new Time[course.getNumSplits()];

       /* Compute the elasped times */
       int sum = 0;
       for (int iCount=0;
            iCount < course.getNumSplits();
            iCount++)
       {
         sum = sum + splitTimes[iCount].asSeconds();
         elaspedTimes[iCount] = new Time(sum);
       }

     }
     return(elaspedTimes[i]);
  }

  public Time getActualTime(int i)
  {
    int seconds = startTime.asSeconds() +
                      getElaspsed(i).asSeconds();
      return( new Time(seconds) );
  }

  public Time getStartTime()
  {
    return startTime;
  }

  public int getPosition()
  {
    return course.getPosition(this);
  }

  public String getFullName()
  {
    return fullName;
  }

  public String getNameAndTime()
  {
    return fullName + "  " + getTotalTime().toString() ;
  }

  private String firstName;
  private String surname;
  private String club;
  private Course course;
  private Time startTime  = null;

  private Time[] splitTimes = null;
  private Time[] actualTimes = null;
  private int[] positions   = null;
  private transient Time[] elaspedTimes = null;
  private transient String fullName;
}
