/*
 *    SplitsBrowser - Result class.
 *
 *    Copyright (C) 2000  Dave Ryder
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this library; see the file COPYING.  If not, write to
 *    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 *    Boston, MA 02111-1307, USA.
 */

package orienteering.splitsbrowser;

import java.lang.*;
import java.util.*;
import java.awt.event.*;

/**
 * Encapsulates an orienteering result
 *
 * @author <b>Dave Ryder</b>
 * @version 1.0
 */
public class Result extends Object
{

  public Result(Course newCourse,
                Time newStartTime,
                Time[] splits)
  {
    course       = newCourse;
    splitTimes   = splits;
    startTime    = newStartTime;
    elaspedTimes = null;
    course.addResult(this);
  }

  public Result(String newFirstName,
                String newSurname,
                String newClub,
                Course newCourse,
                Time newStartTime,
                Time[] splits)
  {
    this(newCourse, newStartTime, splits);
    setFirstName(newFirstName);
    setSurname(newSurname);
    setClub(newClub);
  }

  public void setFirstName(String newFirstName)
  {
    firstName = newFirstName;
    fullName = firstName + " " + surname;
  }

  public String getFirstName()
  {
    return firstName;
  }

  public void setSurname(String newSurname)
  {
    surname = newSurname;
    fullName = firstName + " " + surname;
  }

  public String getSurname()
  {
    return surname;
  }

  public void setClub(String newClub)
  {
    club = newClub;
  }

  public String getClub()
  {
    return club;
  }

  public Time getTotalTime()
  {
    return getElaspsed( course.getNumSplits()-1 );
  }

  public Time getSplit(int i)
  {
    return splitTimes[i];
  }

  public Time getElaspsed(int i)
  {
     if (elaspedTimes == null)
     {
       /* Create array for the elapsed times */
       elaspedTimes = new Time[course.getNumSplits()];

       /* Compute the elasped times */
       int sum = 0;
       for (int iCount=0;
            iCount < course.getNumSplits();
            iCount++)
       {
         sum = sum + splitTimes[iCount].asSeconds();
         elaspedTimes[iCount] = new Time(sum);
       }

     }
     return(elaspedTimes[i]);
  }

  protected void computeTimeLosses()
  {
    // TODO: This code has just been typed not debugged - should really be a plugin
    int numWorstTimes;

    if (course.getNumControls() < 10) {
       numWorstTimes = 2;
    } else if (course.getNumControls() < 15) {
       numWorstTimes = 3;
    } else {
       numWorstTimes = 4;
    }

    double[] worstLosses = {0,0,0,0};
    int[] worstSplits = {-1,-1,-1,-1};

    /* First find the mistakes that we will ignore in computing how fast our man should go */
    for (int splitCount=0;  splitCount< course.getNumSplits(); splitCount++) {
      for (int i=0; i<numWorstTimes; i++) {

        double lossRate = getSplit(i).asSeconds() / course.getOptimumTime(splitCount).asSeconds();

        if (lossRate > worstLosses[i]) {
          worstLosses[i] = lossRate;
          worstSplits[i] = i;
          break;
        }
      }
    }

    // Subtract the worst splits from the total time to get his loss rate
    int total = getTotalTime().asSeconds();
    int totalOptimum = course.getOptimumTime( course.getNumSplits() ).asSeconds();

    for (int i=0; i<numWorstTimes; i++) {
      total = total - getSplit(worstSplits[i]).asSeconds();
      totalOptimum = totalOptimum - course.getOptimumTime(worstSplits[i]).asSeconds();
    }

    double lossRate = total / totalOptimum;

    // Finally calculate the time loss for each leg
    for (int i=0;  i<course.getNumSplits(); i++) {
      int expectedTime =  new Double(getSplit(i).asSeconds() * lossRate).intValue();
      timeLoss[i] = new Time(expectedTime - course.getOptimumTime(i).asSeconds() );
    }
  }

  public Time getTimeLoss(int i)
  {
    if (timeLoss == null)
    {
      timeLoss = new Time[course.getNumSplits()];
      computeTimeLosses();
    }
    return( timeLoss[i] );
  }

  public Time getActualTime(int i)
  {
    int seconds = startTime.asSeconds() +
                      getElaspsed(i).asSeconds();
      return( new Time(seconds) );
  }

  public Time getStartTime()
  {
    return startTime;
  }

  public int getPosition()
  {
    return course.getPosition(this);
  }

  public String getFullName()
  {
    return fullName;
  }

  public String getNameAndTime()
  {
    return fullName + "  " + getTotalTime().toString() ;
  }

  private String firstName;
  private String surname;
  private String club;
  private Course course;
  private Time startTime  = null;

  private Time[] splitTimes = null;
  private Time[] actualTimes = null;
  private int[] positions   = null;
  private transient Time[] elaspedTimes = null;
  private transient String fullName;
  private transient Time[] timeLoss = null;
}
