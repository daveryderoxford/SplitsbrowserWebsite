/*
 *    SplitsBrowser - CVSOutputStream.
 *
 *    Copyright (C) 2000  Dave Ryder
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this library; see the file COPYING.  If not, write to
 *    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 *    Boston, MA 02111-1307, USA.
 */

//package orienteering.splitsbrowser.model;

import java.io.*;

public class CVSOutputStream extends DataOutputStream
{

  public CVSOutputStream(OutputStream out, OEvent theEvent)
  {
    super(out);
    event = theEvent;
  }

  public void writeEvent() throws IOException
  {
    writeChars(event.getName() );
    writeChars("\n");

    Course course;

    for (int i=0; i<event.getNumCourses(); i++) {

      course = event.getCourse(i);

      writeChars(course.getName());
      writeChars(",");
      writeInt(course.getNumControls());
      writeChars("\n");

      Result result;

      for (int iResult=0; iResult<course.getNumResults(); i++) {

        result = course.getResult(iResult);

        writeChars(result.getFirstName() );
        writeChars(",");
        writeChars(result.getSurname() );
        writeChars(",");
        writeChars(result.getClub() );
        writeChars(",");
        writeChars(result.getStartTime().toString() );
        writeChars(",");

        int iSplit;

        for (iSplit=0; iSplit<course.getNumSplits()-1; iSplit++) {
          writeChars( result.getSplit(iSplit).toString() );
          writeChars(",");
        }
        writeChars( result.getSplit(iSplit+1).toString() );
        writeChars("\n");
      }

      // Blank line at end of the course
      writeChars("\n");
    }
  }

  private OEvent event;

} 
