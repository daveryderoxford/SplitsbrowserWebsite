/*
 *    SplitsBrowser - Time class.
 *
 *    Copyright (C) 2000  Dave Ryder
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this library; see the file COPYING.  If not, write to
 *    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 *    Boston, MA 02111-1307, USA.
 */

// package orienteering.splitsbrowser.model;

import java.lang.*;
import java.util.*;
import java.text.*;
import java.io.Serializable;

/**
 * A utility time class.
 *
 * @author <b>Dave Ryder</b>
 * @version 1.0
 */
public class Time extends Object implements Serializable
{

  public Time() {}

  /**
   * Constructs a time from minutes and seconds
   *
   * @param minutes number of minutes.  May be greater than 60.
   * @param seconfds number of seconds.  May be greater than 60.
   */
  public Time(int minutes, int seconds)
  {
     secondsFromMidnight = minutes*60 + seconds;
  }

  /**
   * Constructs a time from hours minutes and seconds
   *
   * @param minutes number of hours.
   * @param minutes number of minutes.
   * @param seconfds number of seconds.
   */
  public Time(int hours, int minutes, int seconds)
  {
     secondsFromMidnight = (hours*60 + minutes) * 60 + seconds;
  }

  /**
   * Constructs a time from number of seconds from midnight
   *
   * @param newTime number of seconds.
   */
  public Time(int newTime)
  {
    secondsFromMidnight = newTime;
  }

  /**
   * Returns the number of seconds from midnightgetm
   *
   * @param newTime number of seconds.
   */
  public int asSeconds()
  {
    return( secondsFromMidnight );
  }

  /**
   * Returns the time as a string in mm:ss format.
   * Prefacing it by a - sign if the time is nagative
   */
  public String toString()
  {
    // If we have negative seconds we need to add the - sign by hand
    if (secondsFromMidnight<0)
    {
      return( "-" + pad( getMins() ) + ':' + pad( getSecs() ) );
    } else {
      return( pad( getMins() ) + ':' + pad( getSecs() ) );
    }
  }

  public String toStringSigned()
  {
    // If we have negative seconds append the - sign by hand
    if (secondsFromMidnight<0)
    {
      return( "-" + pad( getMins() ) + ':' + pad( getSecs() ) );
    } else {
      return( " " + pad( getMins() ) + ':' + pad( getSecs() ) );
    }
  }

  /**
   * Gets the number of seconds.
   */
  public int getSecs()
  {
    return( Math.abs(secondsFromMidnight - (getMins()*60)) );
  }

  /**
   * Gets the number of minutes.
   */
  public int getMins()
  {
    return(secondsFromMidnight/60);
  }

  private String pad(int value)
  {
    if (value < 10) {
      return( "0" + new Integer(Math.abs(value)).toString() );
    } else {
      return( new Integer(Math.abs(value)).toString() );
    }
  }

  public final static Time ZERO_TIME = new Time(0);
  private int secondsFromMidnight = 0;
}
