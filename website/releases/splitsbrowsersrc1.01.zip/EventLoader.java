/*
 *    SplitsBrowser - EventLoader.
 *
 *    Copyright (C) 2000  Dave Ryder
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this library; see the file COPYING.  If not, write to
 *    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 *    Boston, MA 02111-1307, USA.
 */

//package orienteering.splitsbrowser.model;

import java.io.*;
import java.lang.*;
import java.util.*;
import java.util.zip.*;
import java.net.*;

/**
 * Loads a single course from a CVS file.
 * The format of the data is
 * CourseName,NumControls
 * FristName, LastName, Club, StartHour:StartMins,
 * Split1Mins:Splits1Sec,....Numcontrols+1 times
 *
 * Each class is terminated by a blank line and the file terminated by two blank lines or
 * the end of the file
 *
 * @author <b>Dave Ryder</b>
 * @version 1.0
 */
public class EventLoader
{
  public EventLoader()
  {
  }

  public EventLoader(OEvent newEvent)
  {
    event = newEvent;
  }

  private boolean notBlank(String line)
  {
    return( (line != null) && (line.trim().length() != 0) );
  }

  public void loadEvent(URL base, String fileName, boolean urlInput, boolean zipped) throws IOException, Exception
  {
     BufferedReader reader = openReader(base, fileName, urlInput, zipped);

   // Read course info
   int lineCount = 0;
    try {

      lineCount++;
      String line = reader.readLine();

      while ( notBlank(line) ) {

        StringTokenizer st = new StringTokenizer( line, ",:" );
        String name = new String( st.nextToken() );
        int numControls = Integer.parseInt( st.nextToken().trim() );

        Course course = new Course(event, name, numControls);

        // Read results until a blank line
        lineCount++;
        line = reader.readLine();

        while ( notBlank(line) ) {
          // Read the result
          st = new StringTokenizer( line, ",:"  );

          // Parse the data
          String firstName = st.nextToken();
          String surname   = st.nextToken();
          String club      = st.nextToken();
          String startHour = st.nextToken();
          String startMin  = st.nextToken();

           // Time startTime = new Time(startHour, startMin, 0);
           Time startTime = new Time(0, 0, 0);

          /* Read the splits data */
          Time splits[] = new Time[numControls+1];
          int mins;
          int secs;

          for (int i=0; i<numControls+1; i++)
          {
            mins  =  Integer.parseInt( st.nextToken().trim() );
            if ( (mins<0) )
            {
              throw new Exception("Invalid minutes in file: " + fileName +
                                    " result for " + surname + "  value " + mins);
            }

            secs  =  Integer.parseInt(  st.nextToken().trim() );
            if ( (secs<0) || (secs>59) )
            {
              throw new Exception("Invalid seconds in file " + fileName +
                                    " result for " + surname + "  value " + secs);
            }
            splits[i] = new Time(mins, secs);
          }

          // ... and create the result
          Result result = new Result(firstName,
                                     surname,
                                     club,
                                     course,
                                     startTime,
                                     splits);

          // Read the next results line
          lineCount++;
          line = reader.readLine();
        }
        // Read next class line
        lineCount++;
        line = reader.readLine();
      }
    } catch (Exception e)  {
       throw new Exception("Error reading CVS format file " +  fileName +" at line " + new Integer(lineCount).toString() +
                          "\n\nError: " + e.toString() );
     }
  }

  protected BufferedReader openReader(URL base, String fileName, boolean urlInput, boolean zipped) throws IOException, Exception
  {
    InputStream inputStream;
    BufferedReader reader;

    try
    {
      if (urlInput) {
        URL myURL = new URL(base, fileName);
        DataInputStream stream = new DataInputStream(myURL.openStream());
        inputStream = stream;

      } else {
         FileInputStream stream = new FileInputStream(fileName);
         inputStream = stream;
      }

      if (zipped) {
        ZipInputStream zippedStream = new ZipInputStream(inputStream);
        // Move to the first file entry
        ZipEntry  entry = zippedStream.getNextEntry();
        reader = new BufferedReader(new InputStreamReader(zippedStream));
      } else {
        reader = new BufferedReader(new InputStreamReader(inputStream));
      }
    } catch (Exception e) {
       throw(new IOException("Error encountered opening file "+ fileName));
    }

    return(reader);
  }

  protected OEvent event;
}
