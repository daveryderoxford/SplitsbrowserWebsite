/*
 *    SplitsBrowser - SportIdentHTMl format loader.
 *
 *    Original Copyright (C) 2000  Dave Ryder
 *
 *    Version T Copyright (C) 2001 Ed Nash
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this library; see the file COPYING.  If not, write to
 *    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 *    Boston, MA 02111-1307, USA.
 */

// package orienteering.splitsbrowser.model;

import java.io.*;
import java.lang.*;
import java.util.*;
import java.net.*;
import java.util.zip.*;

/**
 * Loads event details from an SI .html file
 * Assumes as little as possible, since the exact format seems to change frequently
 * Reads each line then attempts to class it as a
 * 1. course header
 * 2. control info
 * 3. competitor first line
 * 4. retiral first line
 * 5. non-comp finisher first line
 * 6. competitor second line
 * 7. competitor subsequent line
 * Then processes the line depending on what it is
 * Written 10/2001 by Ed Nash
 * Incorporates some ideas from Convert 2.0 by Ed Nash (1999)
 * Incorporates other ideas from SiteSearch by Ed Nash (2001)
 * Incorporates further ideas from Dave Ryder's v1.0 SIEventLoader class
 * a TROLL production 2001
 * version T.01
 * version history:
 * v T.00 - Ed's original effort
 * v T.01 - added HTML special character decoding and Hm as a climb symbol
 */
public class SIEventLoader extends EventLoader {

  // various foreign options - add more as you find 'em!
  private static final String FINISH_SYMBOLS = "A<F<Z<M";
  private static final String NUM_CONTROLS_SYMBOLS = "C<P";
  private static final String DSQ_SYMBOLS = "pm<mp<Felst.<Fehlst<Aufg";
  private static final String NON_COMP_SYMBOLS = "nc<aK";
  private static final String KM_SYMBOLS = "km<m";
  private static final String CLIMB_SYMBOLS = "Cm<Hm";

  // line types
  private static final int UNKNOWN = 0;		// line unrecognised
  private static final int COURSE_HEADER = 1;	// course name, length [, climb, no. controls]
  private static final int COURSE_INFO = 2;	// list of control codes
  private static final int COMP_FIRST = 3;	// posn, id, name [, class], total time, splits
  private static final int NON_COMP_FIRST = 4;	// aK, id, name [, class], total time, splits
  private static final int DSQ_FIRST = 5;	// id, name [,class], mp|pm|Felst., splits
  private static final int COMP_SECOND = 6;	// club, splits
  private static final int COMP_SUBSQ = 7;	// splits

    // token types
  private static final int STRING = 0;
  private static final int FLOAT = 1;
  private static final int INTEGER = 2;
  private static final int TIME = 3;
  private static final int KM = 4;
  private static final int CLIMB = 5;
  private static final int NUM_CONTROLS = 6;
  private static final int NUM_COMPETITORS = 7;
  private static final int CONTROL_CODE = 8;
  private static final int FINISH = 9;
  private static final int NON_COMP = 10;
  private static final int MISPUNCH = 11;


	// HTML defined special characters and Unicode equivalents
  private static final String specialChars[] = {	"&nbsp;",	"&iexcl;",	"&cent;",	"&pound;",
  													"&curren;",	"&yen;",	"&brvbar;",	"&sect;",
  													"&uml;",	"&copy;",	"&ordf;",	"&laquo;",
  													"&not;",	"&shy;",	"&reg;",	"&macr;",
  													"&deg;",	"&plusmn;",	"&sup2;",	"&sup3;",
  													"&acute;",	"&micro;",	"&para;",	"&middot",
  													"&cedil;",	"&sup1;",	"&ordm;",	"&raquo;",
  													"&frac14;",	"&frac12;",	"&frac34;",	"&iquest;",
  													"&Agrave;",	"&Aacute;",	"&Acirc;",	"&Atilde;",
  													"&Auml;",	"&Aring;",	"&AElig;",	"&Ccedil;",
  													"&Egrave;",	"&Eacute;",	"&Ecirc;",	"&Euml;",
  													"&Igrave;",	"&Iacute",	"&Icirc;",	"&Iuml;",
  													"&ETH;",	"&Ntilde;",	"&Ograve;",	"&Oacute;",
  													"&Ocirc;",	"&Otilde;",	"&Ouml;",	"&times;",
  													"&Oslash;",	"&Ugrave;",	"&Uacute;",	"&Ucirc;",
  													"&Uuml;",	"&Yacute;",	"&THORN;",	"&szlig;",
  													"&agrave;",	"&aacute;",	"&acirc;",	"&atilde;",
  													"&auml;",	"&aring;",	"&aelig;",	"&ccedil;",
  													"&egrave;",	"&eacute;",	"&ecirc;",	"&euml;",
  													"&igrave;",	"&iacute;",	"&icirc;",	"&iuml;",
  													"&eth;",	"&ntilde;",	"&ograve;",	"&oacute;",
  													"&ocirc;",	"&otilde;",	"&ouml;",	"&divide;",
  													"&oslash;",	"&ugrave;",	"&uacute;",	"&ucirc;",
  													"&uuml;",	"&yacute;",	"&thorn;",	"&yuml;",
  													"&quot;",	"&amp;",	"&lt;",		"&gt;",
  													"&OElig;",	"&oelig;",	"&Scaron;",	"&scaron;",
  													"&Yuml;",	"&circ;",	"&tilde;",	"&ensp;",
  													"&emsp;",	"&thinsp;",	"&zwnj;",	"&zwj;",
  													"&lrm;",	"&rlm;",	"&ndash;",	"&mdash;",
  													"&lsquo;",	"&rsquo;",	"&sbquo;",	"&ldquo;",
  													"&rdquo;",	"&bdquo;",	"&dagger;",	"&Dagger;",
  													"&permil;",	"&lsaquo;",	"&rsaquo;",	"&euro;"};

  private static final char translatedChar[] = {	'\u00a0',	'\u00a1',	'\u00a2',	'\u00a3',
  													'\u00a4',	'\u00a5',	'\u00a6',	'\u00a7',
  													'\u00a8',	'\u00a9',	'\u00aa',	'\u00ab',
  													'\u00ac',	'\u00ad',	'\u00ae',	'\u00af',
  													'\u00b0',	'\u00b1',	'\u00b2',	'\u00b3',
  													'\u00b4',	'\u00b5',	'\u00b6',	'\u00b7',
  													'\u00b8',	'\u00b9',	'\u00ba',	'\u00bb',
  													'\u00bc',	'\u00bd',	'\u00be',	'\u00bf',
  													'\u00c0',	'\u00c1',	'\u00c2',	'\u00c3',
  													'\u00c4',	'\u00c5',	'\u00c6',	'\u00c7',
  													'\u00c8',	'\u00c9',	'\u00ca',	'\u00cb',
  													'\u00cc',	'\u00cd',	'\u00ce',	'\u00cf',
  													'\u00d0',	'\u00d1',	'\u00d2',	'\u00d3',
  													'\u00d4',	'\u00d5',	'\u00d6',	'\u00d7',
  													'\u00d8',	'\u00d9',	'\u00da',	'\u00db',
  													'\u00dc',	'\u00dd',	'\u00de',	'\u00df',
  													'\u00e0',	'\u00e1',	'\u00e2',	'\u00e3',
  													'\u00e4',	'\u00e5',	'\u00e6',	'\u00e7',
  													'\u00e8',	'\u00e9',	'\u00ea',	'\u00eb',
  													'\u00ec',	'\u00ed',	'\u00ee',	'\u00ef',
  													'\u00f0',	'\u00f1',	'\u00f2',	'\u00f3',
  													'\u00f4',	'\u00f5',	'\u00f6',	'\u00f7',
  													'\u00f8',	'\u00f9',	'\u00fa',	'\u00fb',
  													'\u00fc',	'\u00fd',	'\u00fe',	'\u00ff',
  													'\u0022',	'\u0026',	'\u003c',	'\u003e',
  													'\u0152',	'\u0153',	'\u0160',	'\u0161',
  													'\u0178',	'\u02c6',	'\u02dc',	'\u2002',
  													'\u2003',	'\u2009',	'\u200c',	'\u200d',
  													'\u200e',	'\u200f',	'\u2013',	'\u2014',
  													'\u2018',	'\u2019',	'\u201a',	'\u201c',
  													'\u201d',	'\u201e',	'\u2020',	'\u2021',
  													'\u2030',	'\u2039',	'\u203a',	'\u20ac'};


  private int line = 0;

  public SIEventLoader(OEvent newEvent)
  {
    super(newEvent);
  }

  public void loadEvent(URL base, String fileName, boolean urlInput, boolean zipped) throws IOException, Exception
  {

	String st = "", name = "", firstName = "", surname = "", club = "";
	Time startTime = new Time(0, 0);
	Time[] splits;
	int numControls = 0;
	Course course = new Course(event);
	BufferedReader reader = openReader(base, fileName, urlInput, zipped);
	Vector tokens;

	line = 0;
	boolean doingSomeone = false;

    try
    {
		// get line
      st = getLine( reader).trim();
      while (st != null) {
		if ((st = st.trim()).length() > 0) {
				// determine line type
			tokens = splitTokens(st);
			switch (lineType(tokens)) {
				case COURSE_HEADER:	// get course name
					int tNum = 0;
					name = "";
					while ((tokenType((String) tokens.elementAt(tNum)) != FLOAT)
					  && (tokenType((String) tokens.elementAt(tNum)) != NUM_COMPETITORS)
					  && (tNum < tokens.size()))
						name = name.concat(" ").concat((String) tokens.elementAt(tNum++)).trim();
					  name = translateChars(name);
				  break;
				case COURSE_INFO:	// get number of controls
					while (FINISH_SYMBOLS.indexOf(st.substring(st.length() - 1)) == -1) {
						st = st.concat(" ").concat(getLine(reader)).trim();
					}
					numControls = splitTokens(st).size() - 1;
					course = new Course(event, name, numControls);
				  break;
				case COMP_FIRST:	// get name of competitor
				case NON_COMP_FIRST:	// include non-comps in calcs
					int firstTime = tokens.size() - 1;
					while (tokenType((String) tokens.elementAt(firstTime)) == TIME) firstTime--;
					int numSurnames = firstTime - 3;
					firstName = (String) tokens.elementAt(2);
					surname = "";
					for (int i = 3; i <= firstTime; i++) {
						surname = surname.concat(" ").concat((String) tokens.elementAt(i)).trim();
					}
					firstName = translateChars(firstName);
					surname = translateChars(surname);
					doingSomeone = true;
				  break;
				case DSQ_FIRST:	// ignore 'em!
					doingSomeone = false;
				  break;
				case COMP_SECOND:	// get the club and their split times, fetching further lines as required
					if (doingSomeone) {
						int numTimes = 0;
						splits = new Time[numControls + 1];
						for (int i = 0; i < tokens.size(); i++) {
						 if (tokenType((String) tokens.elementAt(i)) == TIME) numTimes++;
						}
						while (numTimes < (numControls + 1)) {
							String dummy=getLine(reader);
							String nextLine = getLine(reader).trim();
							Vector newTokens = splitTokens(nextLine);
							for (int i = 0; i < newTokens.size(); i++)
							  if (tokenType((String) newTokens.elementAt(i)) == TIME) numTimes++;
							st = st.concat(" ").concat(nextLine);
						}
						tokens = splitTokens(st);
						int splitNum = 0;
						String token;
						for (int i = 0; i < tokens.size(); i++) {
							token = ((String) tokens.elementAt(i));
							if (tokenType(token) == TIME) {
								if (splitNum <= numControls) {
									splits[splitNum] = parseSplit(token);
									splitNum++;
								}
							} else {
								club = club.concat(" ").concat(token).trim();
							}
						}
						club = translateChars(club);

						Result result = new Result(firstName,
												   surname,
												   club,
												   course,
												   startTime,
												   splits);

						doingSomeone = false;
					}
				  break;
			}
		}
		st = getLine(reader);
      }
    } catch( Exception e) {
       throw( new IOException("Error reading SportIdent HTML file around line: " + new Integer(line).toString() +
               "\n" + "Data: " + st + "\n\n Error: " + e.toString() ) );
    }

  }

  private String getLine(BufferedReader reader) throws IOException {
	  // get a line from the buffer and strip HTML
	  // appending other lines if tags span lines

    line++;
    String buffer = reader.readLine();
    if ((buffer != null) && (buffer.length() > 0)) {
		int tagStart;
		while ((tagStart = buffer.indexOf("<")) != -1) {
			int tagEnd;
			try {
				while ((tagEnd = buffer.indexOf(">", tagStart)) == -1) {
					buffer = buffer.concat(" ".concat(reader.readLine()));
					line++;
				}
				String beforeTag = (tagStart > 0) ? buffer.substring(0, tagStart) : "";
				String afterTag = (tagEnd < buffer.length()) ? buffer.substring(tagEnd + 1, buffer.length()) : "";
				buffer = beforeTag.concat(afterTag);
			}
			catch (Exception e) {
				throw new IOException("Error removing HTML tags");
			}
		}
	}
	return(buffer);
  }

  private Vector splitTokens(String buffer) {
	  // breaks down buffer by spaces and returns vector of tokens

	buffer = buffer.trim();
	Vector returnedTokens = new Vector(0, 1);
	if (buffer.indexOf(" ") != -1) {
		int tokenEnd;
		while ((tokenEnd = buffer.indexOf(" ")) != -1) {
			String token = buffer.substring(0, tokenEnd).trim();
			buffer = buffer.substring(tokenEnd, buffer.length()).trim();
			returnedTokens.addElement(token);
		}
	}
	returnedTokens.addElement(buffer);

	return (returnedTokens);
  }

  private int lineType(Vector tokens) {
	  	//returns a line type (integer) constant describing the line

	  int[] tokenTypes = new int[tokens.size()];
	  for (int i = 0; i < tokens.size(); i++) {
		  tokenTypes[i] = tokenType((String) tokens.elementAt(i));
	  }
	  int last = tokenTypes.length - 1;
	  if ((tokenTypes[last] == NUM_CONTROLS) || (tokenTypes[last] == KM))
		  return (COURSE_HEADER);
	  if ((tokenTypes.length >= 3) && (tokenTypes[last - 1] == CONTROL_CODE))
	  	return (COURSE_INFO);
	  if ((tokenTypes.length >= 3) && (tokenTypes[0] == INTEGER) && (tokenTypes[1] == INTEGER) && (tokenTypes[last] == TIME))
	  	return (COMP_FIRST);
	  if (tokenTypes[0] == NON_COMP)
	  	return (NON_COMP_FIRST);
      if ((tokenTypes.length >= 3) && (tokenTypes[0] == INTEGER) && (tokenTypes[1] == STRING) && (tokenTypes[last] == TIME))
        return (DSQ_FIRST);
	  if ((tokenTypes.length >= 2) && (tokenTypes[0] == STRING) && (tokenTypes[last] == TIME))
	  	return (COMP_SECOND);
	  if (tokenTypes[0] == TIME)
	  	return (COMP_SUBSQ);

	  // not recognized

	  return (UNKNOWN);
  }

  private int tokenType(String token) {
	  	// return an integer constant describing the token
	  try {
		  if (KM_SYMBOLS.indexOf(token) != -1) {
			  return(KM);
		  }
		  if ((token.length() == 2) && (CLIMB_SYMBOLS.indexOf(token) != -1)) return(CLIMB);
		  if (NUM_CONTROLS_SYMBOLS.indexOf(token) != -1) return(NUM_CONTROLS);
		  if (token.indexOf("(") != -1) {
			  if ("0123456789".indexOf(token.substring(0, 1)) != -1) return(CONTROL_CODE);
			  if ("0123456789".indexOf(token.substring(1, 1)) != -1) return(NUM_COMPETITORS);
		  }
		  if ((token.length() == 1) && (FINISH_SYMBOLS.indexOf(token) != -1)) return(FINISH);
		  if (NON_COMP_SYMBOLS.indexOf(token) != -1) return(NON_COMP);
		  if ((token.length() >= 1) && (DSQ_SYMBOLS.indexOf(token) != -1)) return(MISPUNCH);
		  if (((token.indexOf(":") != -1) && ("0123456789".indexOf(token.substring(0, 1)) != -1))
		  	|| (token.indexOf("---") != -1) || (token.charAt(0) == '*')) return(TIME);
		  if ((token.indexOf(".") != -1) && ((new Float(token).floatValue()) > 0)) return(FLOAT);
		  if ((Integer.parseInt(token)) > 0) return(INTEGER);
  	  }
	  catch (NumberFormatException e) {
		  return(STRING);
	  }
    return(STRING);
  }

  private Time parseSplit(String split) throws Exception {
	  	// parse a Split token (hh:mm:ss or mm:ss) and return the time it represents

	  String hourString, minString, secString;
	  int firstSep, lastSep;
	  if ((split.indexOf("-----") != -1) || (split.indexOf("*") != -1)) {
		  return (new Time(0, 0));
	  } else {
		  try {
			  if ((firstSep = split.indexOf(":")) == (lastSep = split.lastIndexOf(":"))) {
					// 'normal' mm:ss format
				  minString = split.substring(0, firstSep);
				  secString = split.substring(firstSep + 1);
				  return (new Time(Integer.parseInt(minString), Integer.parseInt(secString)));
			  } else {
					// 'weird' hh:mm:ss format
				  hourString = split.substring(0, firstSep);
				  minString = split.substring(firstSep + 1, lastSep - firstSep);
				  secString = split.substring(lastSep + 1);
				  int hourInt = Integer.parseInt(hourString);
				  int minInt = Integer.parseInt(minString);
				  minInt = minInt + (60* hourInt);
				  return (new Time(minInt, Integer.parseInt(secString)));
			  }
		  }
		  catch (NumberFormatException e) {
			throw(new Exception("Bad split format: ".concat(split)));
		  }
	  }
  }

  private static String translateChars(String buffer) {
	  // strip HTML representations of 'special' chars and replace with chars

	String returnString = buffer;
	int charStart, charEnd, charCode;
	String beforeChar, afterChar, charNum;
	Character newChar;

		// first look for &#nnn; or &#xnnnn etc. representation
		// and convert these to characters
	try {
		while ((charStart = returnString.indexOf("&#")) != -1) {
			if (charStart != 0) {
				beforeChar = returnString.substring(0, charStart);
			} else {
				beforeChar = "";
			}
			charEnd = returnString.indexOf(";", charStart);
			if ((charEnd == -1) || (charEnd > (charStart + 8))) {
				charEnd = returnString.indexOf(" ", charStart);
			}
			charNum = returnString.substring(charStart + 2, charEnd);
			afterChar = returnString.substring(charEnd + 1, returnString.length());
			if (charNum.indexOf("x") != -1) {
				charCode = Integer.decode("0".concat(charNum)).intValue();
			} else {
				charCode = Integer.decode(charNum).intValue();
			}
			newChar = new Character((char) charCode);
			returnString = beforeChar.concat(newChar.toString()).concat(afterChar);
		}
	}
	catch (Exception e) {
		// leave the string unaltered & assume it's just dodgy html char encoding
	}

		// next do the defined 'specials'
	for (int i = 0; i < specialChars.length; i++) {
		while ((charStart = returnString.indexOf(specialChars[i])) != -1) {
			if (charStart != 0) {
				beforeChar = returnString.substring(0, charStart);
			} else {
				beforeChar = "";
			}
			afterChar = returnString.substring(charStart + specialChars[i].length(), returnString.length());
			returnString = beforeChar.concat(new Character(translatedChar[i]).toString()).concat(afterChar);
		}
	}

	return(returnString);
  }
}






