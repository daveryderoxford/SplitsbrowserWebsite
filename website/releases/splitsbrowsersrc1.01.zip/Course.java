/*
 *    SplitsBrowser - Course.
 *
 *    Copyright (C) 2000  Dave Ryder
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this library; see the file COPYING.  If not, write to
 *    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 *    Boston, MA 02111-1307, USA.
 */

//package orienteering.splitsbrowser.model;

import java.lang.*;
import java.awt.*;
import java.util.*;
import java.io.Serializable;

/**
 * An orienteering course
 * Has facilities to caluclate the optimum time for a
 * leg using a plug-in stratagy and the calculation of
 * split positions
 *
 * @author <b>Dave Ryder</b>
 * @version 1.0
 */
public class Course extends Object implements Serializable
{

    public Course(OEvent newEvent) {
      event = newEvent;
      ageClass = "";
      numControls = 0;
    }

   /** Create a course
   * algorithm.  This will handle arrays that are already
   * sorted, and arrays with duplicate keys.<BR>
   *
   * @param newEvent Event the course is part of
   * @param newClass Name of the course
   * @param newNumControls Number of controls
   */
   public Course(OEvent newEvent,
                String newClass,
                int newNumControls) throws Exception
  {
    if (newClass == "")
    {
      throw new Exception("No class name specified");
    }

    if (newNumControls==0)
    {
      throw new Exception("No controls specified");
    }

    event = newEvent;
    event.addCourse(this);
    ageClass = newClass;
    numControls = newNumControls;
    optimumTimes = new Time[getNumSplits()];
    cumulativeOptimumTimes = new Time[getNumSplits()];
  }

   /** Create a course specifying climb and distance
   *
   * @param newEvent Event the course is part of
   * @param newClass Name of the course
   * @param newNumControls Number of controls
   * @param newDistance Course distance in km
   * @param newClimb Climb in m
   */
  public Course(OEvent newEvent,
                String newClass,
                int newNumControls,
                double newDistance,
                double newClimb) throws Exception
  {
    this(newEvent, newClass, newNumControls);
    distance = newDistance;
    climb = newClimb;
  }

	 /** Get name of the course
	 */
  public String getName()
  {
    return ageClass;
  }

	 /** Get course distance
	 */
  public double getDistance()
  {
    return distance;
  }

  /** Get course climb
	 */
  public double getClimb()
  {
    return climb;
  }

  /** Get number of controls
	 */
  public int getNumControls()
  {
    return numControls;
  }

  /** Get the result for a specified final finish position.
	 *
	 * @param position Position of the competitor
	 */
  public Result getResult(int position)
  {
    return( (Result) results.elementAt(position) );
  }

  /** Get the number of split times avaliable for the
   *  course.  This is generally the number of controls + 1
	 */
  public int getNumSplits()
  {
    return numControls + 1;
  }

  /** Add a result to the course.  The result will be placed in
  *   its correct finish position.
  *
	 * @param newResult Presults added to the course
	 */
  public void addResult(Result newResult)
  {
    optimumTimesInvalid = true;
    winner = null;              // invalidate the winner

    // place result in order in the list
    // the most likley case is that ther result should be
    // added to the end so we start there

    int numRes = getNumResults();
    int newTime = newResult.getTotalTime().asSeconds();

    // First result in list
    if (numRes==0) {
      results.addElement(newResult);
      return;
    }

    Result result = getResult(numRes-1);
    boolean lastPlace = (newTime >= result.getTotalTime().asSeconds() );

    if (lastPlace) {
      results.addElement(newResult);
      return;
    }

    int i = 0;
    int time = getResult(i).getTotalTime().asSeconds();

    while (newTime > time) {
      i++;
      time = getResult(i).getTotalTime().asSeconds();
    }
    results.insertElementAt(newResult, i);

    return;
  }

  /** Get the position of a given result
  *
	 * @param result Result to get the position of
	 */
  int getPosition(Result result)
  {
    return( results.indexOf(result) );
  }

  /** Get the number of results
	 */
  public int getNumResults()
  {
    return( results.size() );
  }

  /** Sets the algorithm used to caluculate the optimum time for a each leg
  *
	 * @param newOptimumTimeAlgorithm Algorithm used to calculate the optimum times
	 */
  public void setOptimumTimeAlgorithm(OptimumTimeAlgorithms.IOptimumTimeAlgorithm newOptimumTimeAlgorithm)
  {
      optimumTimeAlgorithm = newOptimumTimeAlgorithm;
      optimumTimesInvalid = true;
  }


  public OptimumTimeAlgorithms.IOptimumTimeAlgorithm getOptimumTimeAlgorithm()
  {
    return optimumTimeAlgorithm;
  }

  /** Returns the optimum time for a leg calculated using the optimum time algorithm
	 */
  public Time getOptimumTime(int i)
  {
    if (optimumTimesInvalid) {
      computeOptimumTimes();
    }

    return(optimumTimes[i]);
  }

  /** Returns the cumulative optimum time for a leg
	 */
  public Time getCumulativeOptimumTime(int i)
  {
    if (optimumTimesInvalid) {
      computeOptimumTimes();
    }

    return(cumulativeOptimumTimes[i]);
  }

  protected void computeOptimumTimes()
  {
    if (optimumTimeAlgorithm != null) {

        int sum = 0;
        for (int j=0; j< getNumSplits(); j++) {
          optimumTimes[j] = optimumTimeAlgorithm.computeTime(this, j);
          sum = sum + optimumTimes[j].asSeconds();
          cumulativeOptimumTimes[j] = new Time(sum);
        }
      } else {
        for (int j=0; j< getNumSplits(); j++) {
          optimumTimes[j] = Time.ZERO_TIME;
          cumulativeOptimumTimes[j] = Time.ZERO_TIME;
        }
      }

      optimumTimesInvalid = false;
    }

  /** Returns the course winner
	 */
  public Result getWinner()
  {
    if (winner == null) {
      int fastestTime = Integer.MAX_VALUE;

      for (int i=0; i<getNumResults(); i++) {
        int inttime = getResult(i).getTotalTime().asSeconds();
        if (inttime < fastestTime) {
          fastestTime = inttime;
          winner = getResult(i);
        }
      }
    }

    return(winner);
  }

  private boolean sortOnSplits;
  private int sortSplit;

  protected void computeSplitPositions(int split) throws Exception
  {
     // Create an array of the results
     Result[] resultsArray =  new Result[results.size()];
     results.copyInto(resultsArray);

     sortSplit = split;
     sortOnSplits = true;
    /* Sort the array based on times for a given split using a
       modified version of the quicksort routine */
    QuickSort(resultsArray, 0, resultsArray.length-1, split);
    InsertionSort(resultsArray,0,resultsArray.length-1, split);

    // Set the positions for each of the results
    for (int i=0; i< results.size(); i++) {
      resultsArray[i].setPosition(split, i);
    }
  }

	 /** This is a generic version of C.A.R Hoare's Quick Sort
	 * algorithm.  This will handle arrays that are already
	 * sorted, and arrays with duplicate keys.<BR>
	 *
	 * If you think of a one dimensional array as going from
	 * the lowest index on the left to the highest index on the right
	 * then the parameters to this function are lowest index or
	 * left and highest index or right.  The first time you call
	 * this function it will be with the parameters 0, a.length - 1.
	 *
	 * @param a	   an integer array
	 * @param lo0	 left boundary of array partition
	 * @param hi0	 right boundary of array partition
	 */
	 private void QuickSort(Result a[], int l, int r, int split) throws Exception
  {
    int M = 4;
    int i;
    int j;
    Result v;

    if ( (r-l)>M ) {
     i = (r+l) / 2;

     if (a[l].getSplit(split).asSeconds() > a[i].getSplit(split).asSeconds() ) swap(a,l,i);	// Tri-Median Methode!
     if (a[l].getSplit(split).asSeconds() > a[r].getSplit(split).asSeconds() ) swap(a,l,r);
     if (a[i].getSplit(split).asSeconds() > a[r].getSplit(split).asSeconds() ) swap(a,i,r);

     j = r-1;
     swap(a,i,j);
     i = l;
     v = a[j];

     for(;;) {
       while(a[++i].getSplit(split).asSeconds() < v.getSplit(split).asSeconds());
       while(a[--j].getSplit(split).asSeconds() > v.getSplit(split).asSeconds());
       if (j<i) break;
       swap (a,i,j);
     }
     swap(a,i,r-1);
     QuickSort(a,l,j, split);
     QuickSort(a,i+1,r, split);
    }
  }


  private void InsertionSort(Result a[], int lo0, int hi0, int split) throws Exception
  {
    int i;
    int j;
    Result v;

    for (i=lo0+1; i<=hi0; i++) {
      v = a[i];
      j=i;
      while ( (j>lo0) && (a[j-1].getSplit(split).asSeconds() > v.getSplit(split).asSeconds() ) ) {
        a[j] = a[j-1];
        j--;
      }
      a[j] = v;
    }
  }

  private void swap(Result a[], int i, int j)
  {
    Result T;
    T = a[i];
    a[i] = a[j];
    a[j] = T;
  }

  private double distance;
  private double climb;
  private int numControls;
  private OEvent event;
  private String ageClass;
  private Vector results = new Vector();
  private OptimumTimeAlgorithms.IOptimumTimeAlgorithm optimumTimeAlgorithm = null;
  private transient boolean optimumTimesInvalid = true;
  private transient Time optimumTimes[] = null;
  private transient Time cumulativeOptimumTimes[] = null;
  private transient Result winner = null;
}

