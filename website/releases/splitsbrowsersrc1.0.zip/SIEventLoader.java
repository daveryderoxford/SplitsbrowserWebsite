/*
 *    SplitsBrowser - SportIdentHTMl format loader.
 *
 *    Copyright (C) 2000  Dave Ryder
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this library; see the file COPYING.  If not, write to
 *    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 *    Boston, MA 02111-1307, USA.
 */

// package orienteering.splitsbrowser.model;

import java.io.*;
import java.lang.*;
import java.util.*;
import java.net.*;
import java.util.zip.*;

/**
 * Loads event details from an SI .html file
 * Assumes as little as possible, since the exact format seems to change frequently
 * Reads each line then attempts to class it as a
 * 1. course header
 * 2. control info
 * 3. competitor first line
 * 4. retiral first line
 * 5. non-comp finisher first line
 * 6. competitor second line
 * 7. competitor subsequent line
 * Then processes the line depending on what it is
 * Written 10/2001 by Ed Nash
 * Incorporates some ideas from Convert 2.0 by Ed Nash (1999)
 * Incorporates other ideas from SiteSearch by Ed Nash (2001)
 * Incorporates further ideas from Dave Ryder's v1.0 SIEventLoader class
 * a TROLL production 2001
 * version T.00
 */
public class SIEventLoader extends EventLoader {

  // various foreign options!
  private static final String FINISH_SYMBOLS = "A<F<Z<M";
  private static final String NUM_CONTROLS_SYMBOLS = "C<P";
  private static final String DSQ_SYMBOLS = "pm<mp<Felst.";
  private static final String NON_COMP_SYMBOLS = "nc<aK";
  private static final String KM_SYMBOLS = "km<m";

  // line types
  private static final int UNKNOWN = 0;		// line unrecognised
  private static final int COURSE_HEADER = 1;	// course name, length [, climb, no. controls]
  private static final int COURSE_INFO = 2;	// list of control codes
  private static final int COMP_FIRST = 3;	// posn, id, name [, class], total time, splits
  private static final int NON_COMP_FIRST = 4;	// aK, id, name [, class], total time, splits
  private static final int DSQ_FIRST = 5;	// id, name [,class], mp|pm|Felst., splits
  private static final int COMP_SECOND = 6;	// club, splits
  private static final int COMP_SUBSQ = 7;	// splits

    // token types
  private static final int STRING = 0;
  private static final int FLOAT = 1;
  private static final int INTEGER = 2;
  private static final int TIME = 3;
  private static final int KM = 4;
  private static final int CLIMB = 5;
  private static final int NUM_CONTROLS = 6;
  private static final int NUM_COMPETITORS = 7;
  private static final int CONTROL_CODE = 8;
  private static final int FINISH = 9;
  private static final int NON_COMP = 10;
  private static final int MISPUNCH = 11;

  private int line = 0;

  public SIEventLoader(OEvent newEvent)
  {
    super(newEvent);
  }

  public void loadEvent(URL base, String fileName, boolean urlInput, boolean zipped) throws IOException, Exception
  {

	String st = "", name = "", firstName = "", surname = "", club = "";
	Time startTime = new Time(0, 0);
	Time[] splits;
	int numControls = 0;
	Course course = new Course(event);
	BufferedReader reader = openReader(base, fileName, urlInput, zipped);
	Vector tokens;

	line = 0;
	boolean doingSomeone = false;

    try
    {
      st = getLine( reader).trim();
      while (st != null) {
		if ((st = st.trim()).length() > 0) {
			tokens = splitTokens(st);
			switch (lineType(tokens)) {
				case COURSE_HEADER:
					int tNum = 0;
					name = "";
					while ((tokenType((String) tokens.elementAt(tNum)) != FLOAT)
					  && (tokenType((String) tokens.elementAt(tNum)) != NUM_COMPETITORS)
					  && (tNum < tokens.size()))
						name = name.concat(" ").concat((String) tokens.elementAt(tNum++)).trim();
				  break;
				case COURSE_INFO:
					while (FINISH_SYMBOLS.indexOf(st.substring(st.length() - 1)) == -1) {
						st = st.concat(" ").concat(getLine(reader)).trim();
					}
					numControls = splitTokens(st).size() - 1;
					course = new Course(event, name, numControls);
				  break;
				case COMP_FIRST:
				case NON_COMP_FIRST:
					int firstTime = tokens.size() - 1;
					while (tokenType((String) tokens.elementAt(firstTime)) == TIME) firstTime--;
					int numSurnames = firstTime - 3;
					firstName = (String) tokens.elementAt(2);
					surname = "";
					for (int i = 3; i <= firstTime; i++) {
						surname = surname.concat(" ").concat((String) tokens.elementAt(i)).trim();
					}
					doingSomeone = true;
				  break;
				case DSQ_FIRST:
					doingSomeone = false;
				  break;
				case COMP_SECOND:
					if (doingSomeone) {
						int numTimes = 0;
						splits = new Time[numControls + 1];
						for (int i = 0; i < tokens.size(); i++) {
						 if (tokenType((String) tokens.elementAt(i)) == TIME) numTimes++;
						}
						while (numTimes < (numControls + 1)) {
							String dummy=getLine(reader);
							String nextLine = getLine(reader).trim();
							Vector newTokens = splitTokens(nextLine);
							for (int i = 0; i < newTokens.size(); i++)
							  if (tokenType((String) newTokens.elementAt(i)) == TIME) numTimes++;
							st = st.concat(" ").concat(nextLine);
						}
						tokens = splitTokens(st);
						int splitNum = 0;
						String token;
						for (int i = 0; i < tokens.size(); i++) {
							token = ((String) tokens.elementAt(i));
							if (tokenType(token) == TIME) {
								if (splitNum <= numControls) {
									splits[splitNum] = parseSplit(token);
									splitNum++;
								}
							} else {
								club = club.concat(" ").concat(token).trim();
							}
						}

						Result result = new Result(firstName,
												   surname,
												   club,
												   course,
												   startTime,
												   splits);

						doingSomeone = false;
					}
				  break;
			}
		}
		st = getLine(reader);
      }
    } catch( Exception e) {
       throw( new IOException("Error reading SportIdent HTML file around line: " + new Integer(line).toString() +
               "\n" + "Data: " + st + "\n\n Error: " + e.toString() ) );
    }

  }

  private String getLine(BufferedReader reader) throws IOException
  {
    line++;
    String buffer = reader.readLine();
    if ((buffer != null) && (buffer.length() > 0)) {
		int tagStart;
		while ((tagStart = buffer.indexOf("<")) != -1) {
			int tagEnd;
			try {
				while ((tagEnd = buffer.indexOf(">", tagStart)) == -1) {
					buffer = buffer.concat(" ".concat(reader.readLine()));
					line++;
				}
				String beforeTag = (tagStart > 0) ? buffer.substring(0, tagStart) : "";
				String afterTag = (tagEnd < buffer.length()) ? buffer.substring(tagEnd + 1, buffer.length()) : "";
				buffer = beforeTag.concat(afterTag);
			}
			catch (Exception e) {
				throw new IOException("Error removing HTML tags");
			}
		}
	}
	return(buffer);
  }

  private Vector splitTokens(String buffer) {
	buffer = buffer.trim();
	Vector returnedTokens = new Vector(0, 1);
	if (buffer.indexOf(" ") != -1) {
		int tokenEnd;
		while ((tokenEnd = buffer.indexOf(" ")) != -1) {
			String token = buffer.substring(0, tokenEnd).trim();
			buffer = buffer.substring(tokenEnd, buffer.length()).trim();
			returnedTokens.addElement(token);
		}
	}
	returnedTokens.addElement(buffer);

	return (returnedTokens);
  }

  private int lineType(Vector tokens) {
	  	//returns a line type (constant)
	  int[] tokenTypes = new int[tokens.size()];
	  for (int i = 0; i < tokens.size(); i++) {
		  tokenTypes[i] = tokenType((String) tokens.elementAt(i));
	  }
	  int last = tokenTypes.length - 1;
	  if ((tokenTypes[last] == NUM_CONTROLS) || (tokenTypes[last] == KM))
		  return (COURSE_HEADER);
	  if ((tokenTypes.length >= 3) && (tokenTypes[last - 1] == CONTROL_CODE))
	  	return (COURSE_INFO);
	  if ((tokenTypes.length >= 3) && (tokenTypes[0] == INTEGER) && (tokenTypes[1] == INTEGER) && (tokenTypes[last] == TIME))
	  	return (COMP_FIRST);
	  if (tokenTypes[0] == NON_COMP)
	  	return (NON_COMP_FIRST);
      if ((tokenTypes.length >= 3) && (tokenTypes[0] == INTEGER) && (tokenTypes[1] == STRING) && (tokenTypes[last] == TIME))
        return (DSQ_FIRST);
	  if ((tokenTypes.length >= 2) && (tokenTypes[0] == STRING) && (tokenTypes[last] == TIME))
	  	return (COMP_SECOND);
	  if (tokenTypes[0] == TIME)
	  	return (COMP_SUBSQ);

	  // not recognized

	  return (UNKNOWN);
  }

  private int tokenType(String token) {
	  try {
		  if (KM_SYMBOLS.indexOf(token) != -1) {
			  return(KM);
		  }
		  if (token == "Cm") return(CLIMB);
		  if (NUM_CONTROLS_SYMBOLS.indexOf(token) != -1) return(NUM_CONTROLS);
		  if (token.indexOf("(") != -1) {
			  if ("0123456789".indexOf(token.substring(0, 1)) != -1) return(CONTROL_CODE);
			  if ("0123456789".indexOf(token.substring(1, 1)) != -1) return(NUM_COMPETITORS);
		  }
		  if ((token.length() == 1) && (FINISH_SYMBOLS.indexOf(token) != -1)) return(FINISH);
		  if (NON_COMP_SYMBOLS.indexOf(token) != -1) return(NON_COMP);
		  if ((token.length() >= 1) && (DSQ_SYMBOLS.indexOf(token) != -1)) return(MISPUNCH);
		  if (((token.indexOf(":") != -1) && ("0123456789".indexOf(token.substring(0, 1)) != -1))
		  	|| (token.indexOf("---") != -1) || (token.charAt(0) == '*')) return(TIME);
		  if ((token.indexOf(".") != -1) && ((new Float(token).floatValue()) > 0)) return(FLOAT);
		  if ((Integer.parseInt(token)) > 0) return(INTEGER);
  	  }
	  catch (NumberFormatException e) {
		  return(STRING);
	  }
    return(STRING);
  }

  private Time parseSplit(String split) throws Exception {
	  String hourString, minString, secString;
	  int firstSep, lastSep;
	  if ((split.indexOf("-----") != -1) || (split.indexOf("*") != -1)) {
		  return (new Time(0, 0));
	  } else {
		  try {
			  if ((firstSep = split.indexOf(":")) == (lastSep = split.lastIndexOf(":"))) {
					// 'normal' mm:ss format
				  minString = split.substring(0, firstSep);
				  secString = split.substring(firstSep + 1);
				  return (new Time(Integer.parseInt(minString), Integer.parseInt(secString)));
			  } else {
					// 'weird' hh:mm:ss format
				  hourString = split.substring(0, firstSep);
				  minString = split.substring(firstSep + 1, lastSep - firstSep);
				  secString = split.substring(lastSep + 1);
				  int hourInt = Integer.parseInt(hourString);
				  int minInt = Integer.parseInt(minString);
				  minInt = minInt + (60* hourInt);
				  return (new Time(minInt, Integer.parseInt(secString)));
			  }
		  }
		  catch (NumberFormatException e) {
			throw(new Exception("Bad split format: ".concat(split)));
		  }
	  }
  }
}






