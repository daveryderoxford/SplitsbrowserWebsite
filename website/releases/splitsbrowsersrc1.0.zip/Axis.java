/*
 *    SplitsBrowser - Axis class.
 *
 *    Copyright (C) 2000  Dave Ryder
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this library; see the file COPYING.  If not, write to
 *    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 *    Boston, MA 02111-1307, USA.
 */

//package orienteering.splitsbrowser.view;

//import orienteering.splitsbrowser.model.*;

/**
 * A utility class to manage an axis
 * Is responsible for computing axis limits and gird intervals and
 * mapping between user and pixel spaces
 *
 * @author <b>Dave Ryder</b>, Copyright &#169; 2000
 * @version 1.0,
 */
public class Axis
{

  /**
   * Constructs a new axis
   *
   * @param newRoundTimes Should limits be rounded to the nearest minute
   */
  public Axis(boolean newRoundTimes)
  {
    roundTimes = newRoundTimes;
  }

  public int getMaxPixel()
  {
    return (int) maxPixel;
  }

  public void setMaxPixel(int newMaxPixel)
  {
    maxPixel = newMaxPixel;
    computeMapping();
  }

  public int getMinPixel()
  {
    return (int) minPixel;
  }

  public void setMinPixel(int newMinPixel)
  {
    minPixel = newMinPixel;
    computeMapping();

  }

  public Time getMaxTime()
  {
    return new Time( (int) maxTime);
  }

  public void setMaxTime(Time newMaxTime)
  {
    if (roundTimes)
    {
      /* Round up to the nearest minute */
      maxTime = SEC_PER_MIN * ( (newMaxTime.asSeconds() / SEC_PER_MIN) + 1);
    }
    else
    {
      maxTime = newMaxTime.asSeconds();
    }
    computeMapping();
  }

  public Time getMinTime()
  {
    return new Time( (int) minTime);
  }

  public void setMinTime(Time newMinTime)
  {
    if (roundTimes)
    {
      /* Round down to the nearest minute */
      minTime = (SEC_PER_MIN * (newMinTime.asSeconds() / SEC_PER_MIN) );

       // Round down if min time is positive
       if (newMinTime.asSeconds() < 0) {
          minTime -= SEC_PER_MIN;
       }
    }
    else
    {
      minTime = newMinTime.asSeconds();
    }
    computeMapping();
  }

  public int getNumLabels()
  {
    return ((int)maxTime - firstLabel) / gridInterval + 1;
  }

  public int getLabelPixel(int i)
  {
     return toPixel(firstLabel + i*gridInterval);
  }

  public String getLabelString(int i)
  {
    // Get label string in minutes
    return new Integer( (firstLabel + i*gridInterval) / SEC_PER_MIN ).toString();
  }

  public void setRoundTimes(boolean newRoundPixel)
  {
    roundTimes = newRoundPixel;
    computeMapping();
  }

  public boolean getRoundTimes()
  {
    return roundTimes;
  }

  public Time toTime(int pixel)
  {
    int intTime = (int) (pixel/pixelsPerSec + minTime);

    return( new Time(intTime) );
  }

  public int toPixel(Time time)
  {
    return (int) ( (time.asSeconds()-minTime) * pixelsPerSec + minPixel );
  }

  public int toPixel(int seconds)
  {
    return (int) ( (seconds-minTime) * pixelsPerSec + minPixel );
  }

  private void computeMapping()
  {

    // Ensure that the max time is always one to ensure one tick
    if (maxTime < SEC_PER_MIN) {
      maxTime = SEC_PER_MIN;
    }

    double TimeRange = (maxTime - minTime);
    pixelsPerSec = (maxPixel - minPixel) / TimeRange;

    // Make grid size integer number of minutes with a maximum of 10 intervals
    gridInterval = Math.max( 1, ((int) (TimeRange/SEC_PER_MIN)) /5 ) * SEC_PER_MIN;

    int num = (int) minTime / gridInterval;
    firstLabel = num * gridInterval;
  }

  /* store internally a double to avoid type conversions */
  private double maxPixel = 0;
  private double minPixel = 0;
  private double maxTime = Time.ZERO_TIME.asSeconds();
  private double minTime = Time.ZERO_TIME.asSeconds();

  private transient int firstLabel;    /* first label in seconds */
  private transient int gridInterval;  /* grid interval in seconds */
  private transient double pixelsPerSec;

  private static int SEC_PER_MIN = 60;
  private boolean roundTimes;
}
