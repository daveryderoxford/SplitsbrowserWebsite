/*
 *  Splitsbrowser - Message class
 *
 *  (c) Reinhard Balling, October 2002
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Library General Public
 *  License as published by the Free Software Foundation; either
 *  version 2 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this library; see the file COPYING.  If not, write to
 *  the Free Software Foundation, Inc.,show 59 Temple Place - Suite 330,
 *  Boston, MA 02111-1307, USA.
 */
/*
 * Version control info - Do not edit
 * Created:    Reinhard Balling
 * Version:    $Revision: 1.1 $
 * Changed:    $Date: 2003/08/25 06:31:56 $
 * Changed by: $Author: daveryder $
 */
import java.text.MessageFormat;

import java.util.Locale;
import java.util.ResourceBundle;

/**
 *  This class handles internationalisation.
 *
 * @author     Reinhard Balling
 */
public class Message {
    /**  Description of the Field */
    private static String language = null;

    /**  Description of the Field */
    private static String country;

    /**  Description of the Field */
    private static Locale currentLocale;

    /**  Description of the Field */
    private static ResourceBundle messages;

    /**  Description of the Field */
    private static boolean useLocalArray = false;

    /**  Description of the Field */
    private static String[][] msgText =
    {
        { "Main.KeyTimeDiff", "s" },
        { "Main.KeyPercentBehind", "r" },
        { "Main.KeyActualTime", "a" },
        { "Main.KeyPos", "p" },
        { "Main.KeySplitPos", "l" },
        { "Main.KeyResultsTable", "t" },
        { "Main.TimeDifferenceGraph", "Graph: S)plittimes" },
        { "Main.PercentBehindGraph", "Graph: peR)cent behind" },
        { "Main.ActualTimeGraph", "Graph: A)bsolute time" },
        { "Main.PosGraph", "Graph: P)osition after leg" },
        { "Main.SplitPosGraph", "Graph: L)eg position" },
        { "Main.ResultsTable", "T)able of results" },
        { "Main.CrossingRunners", "Crossing runners " },
        { "Main.Winner", "Winner" },
        { "Main.FastestTime", "Fastest time" },
        { "Main.AnyRunner", "Any runner" },
        { "Main.Class", "Class" },
        { "Main.View", "View" },
        { "Main.CompareAgainst", "Compare with" },
        { "Main.TotalTime", "Total time" },
        { "Main.TotalPos", "Position" },
        { "Main.SplitTime", "Splittime" },
        { "Main.SplitPos", "Splitposition" },
        { "Main.TimeBehind", "Time behind" },
        { "Main.Runner", "Runner" },
        { "Main.About", "Info" },
        {
            "Main.Loading",
            "\nResults are being read from file {0} ...\n \nWhen results have been loaded you can close your your connection (analysis is off-line)."
        },
        { "Main.LoadingShort", "\nResults are being read from file {0}" },
        { "Main.FileError", "Error loading data. Applet terminated." },
        { "Main.SelectAll", "All" },
        { "Main.DeselectAll", "None" },
        { "Main.ClickHere", "Mouse key(s) for additional information" },
        { "Graph.Start", "Start" },
        { "Graph.Finish", "Finish" },
        { "Graph.NoStartTime", "Starttime(s) missing" },
        { "Graph.Time", "Time (Min)" },
        { "Graph.FastestSplit", "Fastest leg-time" },
        { "Loader.Error", "Error when reading file {0} in line {1}\n\nError: " },
        { "Loader.OpenError", "Error opening file {0}" },
        { "SILoader.UnexpectedCourseHeader", "Unexpected course/agclass header" },
        {
            "SILoader.WrongNoControls",
            "Wrong number of controls. Course {0} has {1,number,integer} controls"
        },
        { "SILoader.MissingCourse", "Missing course/ageclass" },
        {
            "SILoader.MissingFirstLine",
            "The first line (containing the name) is missing for this runner"
        },
        {
            "SILoader.UnknownLine",
            "Unknown line format in line {0,number,integer}."
        },
        {
            "SILoader.HTMLError",
            "Error removing HTML tags (HTML tag not closed ??)"
        },
        { "SILoader.Error", "Error reading SI input file:" },
        { "SILoader.MissingTimes", "Line {1}: Missing times {0}" },
        {
            "SILoader.MissingTime",
            "In FULL results split time must be followed by time and position (Split {0})"
        },
        {
            "SILoader.MissingStartNumber",
            "Wrong or missing startnumber in line {0}"
        },
        {
            "Table.SelectOneClass",
            "Please choose exactly one class to view the results"
        },
        { "Time.BadSplit", "Invalid time format -->" },
        { "ControlCollection.Control", "Control" },
        { "Result.SplitTime", "Error: Splittime {0} is negative. Set to 0." }
    };

    /**  Constructor for the Message object */
    public Message() {
    }

    /**
     * Return a simple message string without parameters
     *
     * @param  msgID  The message identifier
     * @return        The message string
     */
    public static String get(String msgID) {
        return getString(msgID);
    }

    /**
     * Return a formatted message whose first parameter is a String
     *
     * @param  msgID  The message identifier
     * @param  arg0   The String parameter
     * @return        A formatted message
     */
    public static String get(String msgID, String arg0) {
        Object[] args = new Object[1];

        args[0] = arg0;

        MessageFormat msgFmt = new MessageFormat(getString(msgID));

        return msgFmt.format(args);
    }

    /**
     * Return a formatted message whose first parameter is a String and second parameter is an integer
     *
     * @param  msgID  The message identifier
     * @param  arg0   The String parameter
     * @param  arg1   The int parameter
     * @return        A formatted message
     */
    public static String get(String msgID, String arg0, int arg1) {
        Object[] args = new Object[2];

        args[0] = arg0;
        args[1] = new Integer(arg1);

        MessageFormat msgFmt = new MessageFormat(getString(msgID));

        return msgFmt.format(args);
    }

    /**
     *  Description of the Method
     *
     * @param  msgID  Description of the Parameter
     * @param  arg0   Description of the Parameter
     * @return        Description of the Return Value
     */
    public static String get(String msgID, int arg0) {
        Object[] args = new Object[1];

        args[0] = new Integer(arg0);

        MessageFormat msgFmt = new MessageFormat(getString(msgID));

        return msgFmt.format(args);
    }

    /**
     *  Description of the Method
     *
     * @param  msgID  Description of the Parameter
     * @param  args   Description of the Parameter
     * @return        Description of the Return Value
     */
    public static String get(String msgID, Object[] args) {
        MessageFormat msgFmt = new MessageFormat(getString(msgID));

        return msgFmt.format(args);
    }

    /**
     *  Set the Language and the country and load the appropriate messages
     *
     * @param  newLanguage  Description of the Parameter
     * @param  newCountry   Description of the Parameter
     */
    public static void init(String newLanguage, String newCountry) {
        language = newLanguage;
        country = newCountry;
        loadMessages();
    }

    /**
     * Get a message string given the message identifier
     */
    private static String getString(String msgID) {
        boolean OK = true;

        if (language == null) {
            loadMessages();
        }

        if (!useLocalArray) {
            try {
                return messages.getString(msgID);
            } catch (Exception e) {
                OK = false;

                // String not in resource bundle, try the local array
            }
        }

        if (useLocalArray || !OK) {
            int i;

            for (i = 0; i < msgText.length; i++) {
                if (msgID.equals(msgText[i][0])) {
                    return msgText[i][1];
                }
            }
        }

        return "???";
    }

    /**
     * Load message strings from the resource bundle
     */
    private static void loadMessages() {
        try {
            System.out.println("Lang/Country=" + language + "/" + country);
            currentLocale = new Locale(language, country);
            messages = ResourceBundle.getBundle("Messages", currentLocale);
            useLocalArray = false;
            System.out.println(get("Main.Runner"));
        } catch (Exception e) {
            if ((language != null) && (country != null)) {
                System.err.println("Error loading locale specific data for country='" +
                                   country + "'; language='" + language +
                                   "'. Using English instead.");
            }

            useLocalArray = true;
        }
    }
}
