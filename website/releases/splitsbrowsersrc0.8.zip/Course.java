/*
 *    SplitsBrowser - Course.
 *
 *    Copyright (C) 2000  Dave Ryder
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this library; see the file COPYING.  If not, write to
 *    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 *    Boston, MA 02111-1307, USA.
 */

package orienteering.splitsbrowser;

import java.lang.*;
import java.awt.*;
import java.util.*;
import java.beans.*;

public class Course extends Object
{
  public Course(OEvent newEvent,
                String newClass,
                int newNumControls) throws Exception
  {
    if (newClass == "")
    {
      throw new Exception("No class name specified");
    }

    if (newNumControls==0)
    {
      throw new Exception("No controls specified");
    }
    
    event = newEvent;
    event.addCourse(this);
    ageClass = newClass;
    numControls = newNumControls;
    optimumTimes = new Time[getNumSplits()];
    cumulativeOptimumTimes = new Time[getNumSplits()];
  }

  public Course(OEvent newEvent,
                String newClass,
                int newNumControls,
                double newDistance,
                double newClimb) throws Exception
  {
    this(newEvent, newClass, newNumControls);
    distance = newDistance;
    climb = newClimb;
  }

  public String getName()
  {
    return ageClass;
  }

  public double getDistance()
  {
    return distance;
  }

  public double getClimb()
  {
    return climb;
  }

  public int getNumControls()
  {
    return numControls;
  }

  public Result getResult(int i)
  {
    return( (Result) results.elementAt(i) );
  }

  public int getNumSplits()
  {
    return numControls + 1;
  }

  public void addResult(Result newResult)
  {
    optimumTimesInvalid = true;
    winner = null;              // invalidate the winner

    // place result in order in the list
    // the most likley case is that ther result should be
    // added to the end so we start there

    int numRes = getNumResults();
    int newTime = newResult.getTotalTime().asSeconds();

    // First result in list
    if (numRes==0) {
      results.addElement(newResult);
      return;
    }

    Result result = getResult(numRes-1);
    boolean lastPlace = (newTime >= result.getTotalTime().asSeconds() );

    if (lastPlace) {
      results.addElement(newResult);
      return;
    }

    int i = 0;
    int time = getResult(i).getTotalTime().asSeconds();

    while (newTime > time) {
      i++;
      time = getResult(i).getTotalTime().asSeconds();
    }
    results.insertElementAt(newResult, i);

    return;
  }

  int getPosition(Result result)
  {
    return( results.indexOf(result) );
  }

  public int getNumResults()
  {
    return( results.size() );
  }

  public void setOptimumTimeAlgorithm(OptimumTimeAlgorithms.IOptimumTimeAlgorithm newOptimumTimeAlgorithm)
  {
      optimumTimeAlgorithm = newOptimumTimeAlgorithm;
      optimumTimesInvalid = true;
  }

  public OptimumTimeAlgorithms.IOptimumTimeAlgorithm getOptimumTimeAlgorithm()
  {
    return optimumTimeAlgorithm;
  }

  public Time getOptimumTime(int i)
  {
    if (optimumTimesInvalid) {
      computeOptimumTimes();
    }

    return(optimumTimes[i]);
  }

  public Time getCumulativeOptimumTime(int i)
  {
    if (optimumTimesInvalid) {
      computeOptimumTimes();
    }

    return(cumulativeOptimumTimes[i]);
  }

  protected void computeOptimumTimes()
  {
    if (optimumTimeAlgorithm != null) {

        int sum = 0;
        for (int j=0; j< getNumSplits(); j++) {
          optimumTimes[j] = optimumTimeAlgorithm.computeTime(this, j);
          sum = sum + optimumTimes[j].asSeconds();
          cumulativeOptimumTimes[j] = new Time(sum);
        }
      } else {
        for (int j=0; j< getNumSplits(); j++) {
          optimumTimes[j] = Time.ZERO_TIME;
          cumulativeOptimumTimes[j] = Time.ZERO_TIME;
        }
      }

      optimumTimesInvalid = false;
    }

  public Result getWinner()
  {

    if (winner == null) {
      int fastestTime = Integer.MAX_VALUE;

      for (int i=0; i<getNumResults(); i++) {
        int inttime = getResult(i).getTotalTime().asSeconds();
        if (inttime < fastestTime) {
          fastestTime = inttime;
          winner = getResult(i);
        }
      }
    }

    return(winner);
  }

  private double distance;
  private double climb;
  private int numControls;
  private OEvent event;
  private String ageClass;
  private Vector results = new Vector();
  private OptimumTimeAlgorithms.IOptimumTimeAlgorithm optimumTimeAlgorithm = null;
  private transient boolean optimumTimesInvalid = true;
  private transient Time optimumTimes[] = null;
  private transient Time cumulativeOptimumTimes[] = null;
  private transient Result winner = null;
}

