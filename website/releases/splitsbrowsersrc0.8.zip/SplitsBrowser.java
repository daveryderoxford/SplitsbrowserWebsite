/*
 *    SplitsBrowser - SplitsBrowser Applet.
 *
 *    Copyright (C) 2000  Dave Ryder
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this library; see the file COPYING.  If not, write to
 *    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 *    Boston, MA 02111-1307, USA.
 */

package orienteering.splitsbrowser;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.io.*;

public class SplitsBrowser extends Applet {
  boolean isStandalone = false;
  String name;
  String color1;
  String color2;
  String backgroundColor;
  int inputFormat;
  String courseData;

  //Get a parameter value
  public String getParameter(String key, String def) {
    return isStandalone ? System.getProperty(key, def) :
      (getParameter(key) != null ? getParameter(key) : def);
  }

  //Construct the applet

  public SplitsBrowser() {
  }

  public static void main(String[] args) {
    SplitsBrowser applet = new SplitsBrowser();
    applet.isStandalone = true;
    Frame frame = new Frame();
    frame.setTitle("Applet Frame");
    frame.add(applet, BorderLayout.CENTER);
    applet.init();
    applet.start();
    frame.setSize(400,320);
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    frame.setLocation((d.width - frame.getSize().width) / 2, (d.height - frame.getSize().height) / 2);
    frame.addWindowListener(new java.awt.event.WindowAdapter() {
       public void windowClosing(java.awt.event.WindowEvent e) {
         System.exit(0);
       };
    });

    frame.setVisible(true);
  }

//Initialize the applet

  public void init() {

   try {
      jbInit();
    } catch (Exception e) {
      e.printStackTrace();
    }

    try {
      splitsGraph.setColor1( getColorParameter("color1", splitsGraph.getColor1() ) );
    } catch (Exception e) {
      e.printStackTrace();
    }

    try {
      splitsGraph.setColor2( getColorParameter("color2", splitsGraph.getColor2() ) );
    } catch (Exception e) {
      e.printStackTrace();
    }

    try {
      Color c = getColorParameter("background", splitsGraph.getBackground()  ) ;
      this.setBackground(c);
      // Set all the elements of the top panel
      topPanel.setBackground( c );
      classLabel.setBackground( c );
      compareAgainstLabel.setBackground( c );
      viewLabel.setBackground( c );

      this.repaint();

    } catch (Exception e) {
      e.printStackTrace();
    }

    try {
      splitsGraph.setBackground( getColorParameter("graphbackground",  splitsGraph.getColor2() ) );
    } catch (Exception e) {
      e.printStackTrace();
    }

    try {
      inputFormat = Integer.parseInt(this.getParameter("dataformat", "0"));
    } catch (Exception e) {
      e.printStackTrace();
    }

    try {
      boolean zipped = false;
      String ZIPPED_NOT_SPECIFIED = "zzzNotZipped";
      zipped = this.getParameter("zipped",ZIPPED_NOT_SPECIFIED).compareTo(ZIPPED_NOT_SPECIFIED) != 0;

      String inputFilename = this.getParameter("inputdata", "No Course data");

      loadEvent(inputFilename, inputFormat, zipped);
      setEventTimeAlgorithm(OptimumTimeAlgorithms.winner);

    } catch (Exception e) {
       e.printStackTrace();
    }
  }

  public void loadEvent(String inputFilename, int inputFormat, boolean zipped) throws IOException, Exception
  {
    OEvent newEvent = null;

    newEvent = new OEvent("");

    if (inputFormat==SI_HTML_INPUT_FORMAT) {
      loader = new SIEventLoader(newEvent);
    } else {
      loader = new EventLoader(newEvent);
    }
    
  //  loader.loadEvent(inputFilename, false, zipped);
    inputFilename = getDocumentBase() + inputFilename;
    loader.loadEvent(inputFilename, true, zipped);

    Course course = newEvent.getCourse(0);
    setEvent(newEvent);
    splitsGraph.setCourse( course );
  }

  public void setSize(int width, int height)
  {
   /* The setsize method is overwriden to get the applet to
      resize in the browser */
   super.setSize(width,height);
   validate();
  }

  protected Color getColorParameter(String paramName, Color defaultColor)
  {
    final String hexPrefix = "0x";

    // Gets a color parameter in web format of hex

    String str = getParameter(paramName, "").trim();

    // exit if the parameter was not set
    if (str.length() == 0)
    {
      return(defaultColor);
    }

    // ignore a # character on the start of the string as used in HTML
    int start = 0;
    if ( str.startsWith("#") )  {
      start = 1;
    }

    Integer red = new Integer(0);
    String s = hexPrefix + str.substring(start, start+2);
    red = Integer.decode( s );

    Integer green = new Integer(0);
    green = Integer.decode( hexPrefix + str.substring(start+2, start+4) );

    Integer blue = new Integer(0);
    blue = Integer.decode( hexPrefix + str.substring(start+4, start+6) );

    return( new Color( red.intValue(),
                       green.intValue(),
                       blue.intValue() ) );
  }

  public void setEvent(OEvent newEvent)
  {
    event = newEvent;
    classChoice.removeAll();
    resultsList.removeAll();

    // Load the classes - calculating the max size of the
    int maxSize = Integer.MIN_VALUE;
    FontMetrics fontMetrics = classChoice.getFontMetrics(classChoice.getFont());

    for (int i=0; i< event.getNumCourses(); i++ ) {
       String name = event.getCourse(i).getName();
      classChoice.add( name );
      maxSize = Math.max( maxSize, fontMetrics.stringWidth(name) );
    }

    // Resize the choice to the max string size
    int buttonSize = 25;
    classChoice.setSize(maxSize+buttonSize,0);

    topPanel.doLayout();

    splitsGraph.setCourse(null);
    splitsTable.setCourse(null);

    // Select the first course in the list
    classChoice.select(0);

    classChoice_itemStateChanged(null);
  }

  public void setCourse(Course newCourse)
  {
    // Update the course selection
    classChoice.select(newCourse.getName() );
  }

//Component initialization

  private void jbInit() throws Exception {

    // Sizes and layouts
    this.setLayout(borderLayout1);
    this.setSize(400,300);
    topPanel.setLayout(topPanelLayout);
    this.setFont(new Font("SansSerif", 0, 11));
    this.setBackground(new Color(88, 128, 243));
    this.setSize(new Dimension(472, 478));
    topPanelLayout.setAlignment(0);
    mainPanel.setLayout(mainPanelCardLayout);

    // Properties
    classLabel.setAlignment(1);
    classLabel.setText("Class");
    classChoice.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        classChoice_itemStateChanged(e);
      }
    });

    viewLabel.setAlignment(1);
    viewLabel.setText(" View");
    viewChoice.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        viewChoice_itemStateChanged(e);
      }
    });

    textPanel.setLayout(textPanelLayout);
    graphPanel.setLayout(borderLayout2);
    compareAgainstLabel.setAlignment(1);
    compareAgainstLabel.setText("Compare against");
    borderLayout1.setVgap(5);
    resultsList.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        resultsList_actionPerformed(e);
      }
    });
    resultsList.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        resultsList_itemStateChanged(e);
      }
    });
    compareAgainstChoice.addItemListener(new java.awt.event.ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        compareAgainstChoice_itemStateChanged(e);
      }
    });
    splitsTable.setBackground(Color.white);
    this.add(topPanel, BorderLayout.NORTH);

    viewChoice.add(VIEW_DIFFERENCE_GRAPH);
		 viewChoice.add(VIEW_TABLE);
	//	 viewChoice.add(VIEW_ACTUAL_TIME);

		 compareAgainstChoice.add("Winner");
		 compareAgainstChoice.add("Fastest time");
		 compareAgainstChoice.add("Fastest time + 25%");
		 compareAgainstChoice.add("Fastest time + 50%");
		 compareAgainstChoice.add("Fastest time + 100%");

    // Add components
    topPanel.add(classLabel, null);
    topPanel.add(classChoice, null);
    topPanel.add(viewLabel, null);
    topPanel.add(viewChoice, null);
    topPanel.add(compareAgainstLabel, null);
    topPanel.add(compareAgainstChoice, null);
    this.add(mainPanel, BorderLayout.CENTER);
    mainPanel.add(graphPanel, graphPanel.getName() );
    graphPanel.add(resultsList, BorderLayout.WEST);
    graphPanel.add(splitsGraph, BorderLayout.CENTER);
    mainPanel.add(textPanel, textPanel.getName() );
    textPanel.add(splitsTable, BorderLayout.CENTER);
  }

//Start the applet

  public void start() {
  }

//Stop the applet

  public void stop() {
  }

//Destroy the applet

  public void destroy() {
  }

//Get Applet information

  public String getAppletInfo() {
    return "orienteering.splitsbrowser.SplitsBrowser";
  }

//Get parameter info
  
  public String[][] getParameterInfo() {
    String pinfo[][] =
    {
      {"eventname", "String", "Name of the event"},
      {"color", "String", "First color used on the graph"},
      {"colorb", "String", "Second color stripe"},
      {"background", "String", "Background color used for the graph"},
      {"dataformat", "int", "Format for the course input data"},
      {"zipped", "int", "Is the input file zipped"},
      {"inputdata", "String", "Definition of where the data is obtained from"},
    };
    return pinfo;
  }

  // Shared in package for testing
  OEvent event = null;
  Course currentCourse = null;
  EventLoader loader = null;

  public static final int SI_HTML_INPUT_FORMAT = 1;

  private Color backGroundColor = Color.gray;
  Panel topPanel = new Panel();
  Panel mainPanel = new Panel();
  FlowLayout topPanelLayout = new FlowLayout();
  Label classLabel = new Label();
  Choice classChoice = new Choice();
  Label viewLabel = new Label();
  Choice viewChoice = new Choice();
  CardLayout mainPanelCardLayout = new CardLayout();
  Panel graphPanel = new Panel();
  Panel textPanel = new Panel();
  Label compareAgainstLabel = new Label();
  BorderLayout borderLayout1 = new BorderLayout();
  List resultsList = new List(1,true);   // Allow multi select
  BorderLayout borderLayout2 = new BorderLayout();
  Choice compareAgainstChoice = new Choice();
  SplitsGraph splitsGraph = new SplitsGraph();
  BorderLayout textPanelLayout = new BorderLayout();
  SplitsTable splitsTable = new SplitsTable();

  private static String VIEW_DIFFERENCE_GRAPH = "Time difference graph";
  private static String VIEW_TABLE            = "Results table";
  private static String VIEW_ACTUAL_TIME      = "Actual time graph";

  protected Insets insets = new Insets(7,7,7,7);

  void viewChoice_itemStateChanged(ItemEvent e) {
    String str = viewChoice.getSelectedItem();

    try
    {
      if ( str == VIEW_DIFFERENCE_GRAPH ) {
        mainPanelCardLayout.first(mainPanel);
        splitsGraph.setGraphType( splitsGraph.GRAPH_TYPE_COMPARISON );
      } else if (str == VIEW_ACTUAL_TIME ) {
        mainPanelCardLayout.first(mainPanel);
        splitsGraph.setGraphType( splitsGraph.GRAPH_TYPE_RACE );
      } else if (str == VIEW_TABLE) {
        mainPanelCardLayout.last(mainPanel);
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  private void setEventTimeAlgorithm(OptimumTimeAlgorithms.IOptimumTimeAlgorithm algorithm)
  {
    for (int i=0; i < event.getNumCourses(); i++) {
      event.getCourse(i).setOptimumTimeAlgorithm( algorithm );
    }
  }

  void compareAgainstChoice_itemStateChanged(ItemEvent e)
  {
    // Change the comparison algorithm

    // Set the optimum time algorithm for all the courses
   switch ( compareAgainstChoice.getSelectedIndex() ) {
      case -1:
        break;
      case 0:
        setEventTimeAlgorithm( OptimumTimeAlgorithms.winner );
        break;
      case 1:
        setEventTimeAlgorithm( OptimumTimeAlgorithms.fastest );
        break;
      case 2:
        OptimumTimeAlgorithms.percentBehind.setPercentBehind(25);
        setEventTimeAlgorithm( OptimumTimeAlgorithms.percentBehind );
        break;
      case 3:
        OptimumTimeAlgorithms.percentBehind.setPercentBehind(50);
        setEventTimeAlgorithm( OptimumTimeAlgorithms.percentBehind );
        break;
      case 4:
        OptimumTimeAlgorithms.percentBehind.setPercentBehind(100);
        setEventTimeAlgorithm( OptimumTimeAlgorithms.percentBehind );
        break;
      default:
         break;
     }


     splitsGraph.invalidateDimensions();
     splitsTable.setCourse(currentCourse);
  }

  void classChoice_itemStateChanged(ItemEvent e)
  {
     // Find the course
     if (classChoice.getSelectedIndex() == -1) return;

     currentCourse = event.getCourse( classChoice.getSelectedIndex() );

     splitsGraph.setCourse(currentCourse);
     splitsTable.setCourse(currentCourse);

     //  Update the results list
     resultsList.setVisible(false);
     resultsList.removeAll();

     for (int i=0; i<currentCourse.getNumResults(); i++ ) {
       resultsList.add(currentCourse.getResult(i).getFullName() );
     }

     resultsList.setVisible(true);
  }

  int lastIndex = -1;

  void resultsList_itemStateChanged(ItemEvent e)
  {
    // Find the result we have selected
    Integer index = (Integer) e.getItem();
    lastIndex = index.intValue();

    if (index.intValue() != -1) {

      Result theResult = currentCourse.getResult( index.intValue() );

      if ( e.getStateChange() == ItemEvent.SELECTED ) {
        splitsGraph.displayResult(theResult);
      } else {
        splitsGraph.removeResult(theResult);
      }
    }
  }
  public Insets insets()
  {
    return this.insets;
  }

  void resultsList_actionPerformed(ActionEvent e) {
    // Double click handler - a bodge to get round a bug where
    // double clicking on a selected item leaves it selected
    // but only generates a single selection event

    Result theResult = currentCourse.getResult( lastIndex );
    if (splitsGraph.isDisplayed(theResult) ) {
         resultsList.select(lastIndex);
    } else {
        resultsList.deselect(lastIndex);
    }
  }

}

