/*
 *    SplitsBrowser - SportIdentHTMl format loader.
 *
 *    Copyright (C) 2000  Dave Ryder
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this library; see the file COPYING.  If not, write to
 *    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 *    Boston, MA 02111-1307, USA.
 */

package orienteering.splitsbrowser;

import java.io.*;
import java.lang.*;
import java.util.*;
import java.net.*;
import java.util.zip.*;


public class SIEventLoader extends EventLoader {

  private static final String COURSE_TAG = "<B>";
  private static final String RESULT_TAG = "<FONT color=#0000ff size=3> ";

  private static final int FONT_START = 27;
  private static final int FONT_END = 7;
  private static final int ITALIC_FONT_START = 30;
  private static final int ITALIC_FONT_END = 11;
  private static final int POS_SIZE = 5;
  private static final int NAME_SIZE = 18;
  private static final int CLUB_SIZE = 18;

  public SIEventLoader(OEvent newEvent)
  {
    super(newEvent);
  }

  public void loadEvent(String fileName, boolean urlInput, boolean zipped) throws IOException, Exception
  {

    int line = 0;
    BufferedReader reader = openReader(fileName, urlInput, zipped);

    // Courses are identified by a <B> tag at the start of the line
    String st = "";

    try
    {
      line++;
      st = reader.readLine();
      while ((st != null)) {

        if (st.startsWith( COURSE_TAG) ) // We have found a course
        {
          // We assume that the first 20 characters after the <B> are the name
          String name = st.substring(3,23).trim();

          // Get the number of controls - between Cm and C tags
          int startNumControls = st.indexOf("Cm",23) + 2;
          int endNumControls = st.indexOf("C", startNumControls);
          int numControls = Integer.parseInt( st.substring(startNumControls,endNumControls).trim() );

          // Create a course
          Course course = new Course(event, name, numControls);

          // Get the number of controls on an output line  by counting the starting brackets 
          line++;
          st = reader.readLine();
          int controlsPerLine = 0;
          int pos = 0;
          while (st.indexOf("(", pos) != -1) {
            pos =  st.indexOf("(", pos)+1;
            controlsPerLine++;
          }
          if (st.indexOf("F", pos) != -1)
          {
            controlsPerLine++;
          }

          // Skip blank lines
          do {
            line++;
            st = reader.readLine();
          } while ( st.startsWith(" ") );

          // A Result is on a single line starting with a font tag
          // there may possibly be mispunches in the results stream
          int positionCount = 0;

          line++;
          st = reader.readLine();

          int min;
          int sec;
          int startPos;

          while ( (st != null) && st.startsWith(RESULT_TAG)  ) {
            positionCount++;
            // Assume that the results are in a fixed format
            // which is only disturbed by the font start and end tags

            // First line has position and name

            startPos = FONT_START;

            String temp = st.substring( startPos, startPos+POS_SIZE);
          //  int pos = Integer.parseInt( temp.trim() );

           // Parse the competitor name
            startPos = 3*FONT_START + 2*FONT_END + 12;
            String fullName = st.substring( startPos, startPos+NAME_SIZE).trim();
            String firstName;
            String surname;
            if (fullName.indexOf(" ") != -1) {
              firstName = fullName.substring(0, fullName.indexOf(" ") );
              surname = fullName.substring( fullName.indexOf(" "), fullName.length() );
            } else {
              firstName = fullName;
              surname = "";
            }

            startPos += NAME_SIZE + FONT_END + FONT_START+ 1;
            String totalTime =  st.substring( startPos, startPos+8);

            // Second line has club and splits
            st = reader.readLine();

            // Ignore miss punchings for the moment
            if (totalTime.trim().compareTo("mp") != 0 )
            {
              int TIME_SIZE;

              startPos = 12 + FONT_START;
              String club = st.substring( startPos, startPos+CLUB_SIZE).trim();

              startPos += CLUB_SIZE + FONT_END;
              String t1 = st.substring(startPos+12,startPos+13);
              String t2 = st.substring(startPos+9,startPos+10);
              if ( ( t1.compareTo(":")==0) ||
                   ( t2.compareTo("<")==0 ) )  {
                TIME_SIZE = 7;
              } else {
                TIME_SIZE = 8;
              }
              
              startPos += TIME_SIZE + 1;

              Time splits[] = new Time[numControls+1];
              Time startTime = new Time(0, 0);
              int mins;
              int secs;
              int count = 0;

              for (int i=0; i<numControls+1; i++)
              {
                if (count==controlsPerLine)
                {
                  line++;
                  st = reader.readLine();
                  line++;
                  st = reader.readLine();
                  startPos = 38;
                  count = 0;
                }

                startPos = skipFontTags( st, startPos );

                temp = st.substring(startPos+TIME_SIZE-5, startPos+TIME_SIZE-3);
                if (temp.compareTo("  ")==0) {
                  mins = 0;
                } else {
                  mins = Integer.parseInt( temp.trim() );
                }
                if ( (mins<0) )
                {
                  throw new Exception("Invalid minutes in file: " + fileName +
                                        " result for " + surname + "  value " + mins);
                }

                // The time is blank if no split is present
                temp = st.substring(startPos+TIME_SIZE-2, startPos+TIME_SIZE);
                if (temp.compareTo("  ")==0) {
                    secs = 0;
                } else {
                  secs = Integer.parseInt( temp.trim() );
                }

                if ( (secs<0) || (secs>59) )
                {
                  throw new Exception("Invalid seconds in file " + fileName +
                                        " result for " + surname + "  value " + secs);
                }
                startPos += TIME_SIZE;

                splits[i] = new Time(mins, secs);

                count++;
              }

              // ... and create the result
              Result result = new Result(firstName,
                                         surname,
                                         club,
                                         course,
                                         startTime,
                                         splits);
            }
            // Read the next results line
            st = reader.readLine();
          }
        } else {
          line++;
          st = reader.readLine();
        }
      }
    } catch( Exception e) {
       throw( new IOException("Error reading file at line: " + new Integer(line).toString() + "\n" + "Data:" + st) );
    }

  }

  private int skipFontTags(String st, int startPos)
  {
    // Increments the startPosition to skip the highlighted fastest splits
    String temp = st.substring(startPos+1,startPos+2);
    if ( temp.compareTo("<")==0 ) {
      startPos += ITALIC_FONT_START;
      startPos = skipFontTags(st, startPos);
    } else if ( st.substring(startPos,startPos+1).compareTo("<") == 0 ) {
      startPos += ITALIC_FONT_END;
      startPos = skipFontTags(st, startPos);
    }
    return(startPos);
  }

}







