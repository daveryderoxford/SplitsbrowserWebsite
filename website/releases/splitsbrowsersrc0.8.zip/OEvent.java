/*
 *    SplitsBrowser - Event class.
 *
 *    Copyright (C) 2000  Dave Ryder
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this library; see the file COPYING.  If not, write to
 *    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 *    Boston, MA 02111-1307, USA.
 */

package orienteering.splitsbrowser;

import java.lang.*;
import java.util.*;

public class OEvent extends Object
{
  public OEvent(String newName)
  {
    name = newName;
  }

  public OEvent(String newName, java.util.Calendar newDate)
  {
    name = newName;
    date = newDate;
  }

  public String getName()
  {
    return name;
  }

  public java.util.Calendar getDate()
  {
    return date;
  }

  public void addCourse(Course newCourse)
  {
    courses.addElement(newCourse);
  }

  public Course getCourse(int i)
  {
    return( (Course) courses.elementAt(i) );
  }

  public int getNumCourses()
  {
    return( courses.size() );
  }

  private String name;
  private java.util.Calendar date;
  private Vector courses = new Vector();
}

