/*
 *    SplitsBrowser - SportIdentHTMl format loader.
 *
 *    Original Copyright (C) 2000  Dave Ryder
 *
 *    Version T Copyright (C) 2001 Ed Nash
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this library; see the file COPYING.  If not, write to
 *    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 *    Boston, MA 02111-1307, USA.
 */

import java.io.*;
import java.lang.*;
import java.util.*;
import java.net.*;
import java.util.zip.*;
import Token;

/**
 * Loads event details from an SI .html file
 * Assumes as little as possible, since the exact format seems to change frequently
 * Reads each line then attempts to class it as a
 * 1. course header
 * 2. control info
 * 3. competitor first line
 * 4. retiral first line
 * 5. non-comp finisher first line
 * 6. competitor second line
 * 7. competitor subsequent line
 * Then processes the line depending on what it is
 * Written 10/2001 by Ed Nash
 * Incorporates some ideas from Convert 2.0 by Ed Nash (1999)
 * Incorporates other ideas from SiteSearch by Ed Nash (2001)
 * Incorporates further ideas from Dave Ryder's v1.0 SIEventLoader class
 * a TROLL production 2001
 * version T.01
 * version history:
 * v T.00 - Ed's original effort
 * v T.01 - added HTML special character decoding and Hm as a climb symbol
 * 1.02 Code added to make make id optional by KLR.
 * 1.03 Added code to handle blank lines within the splits blocks DKR
 * 1.04 Code added to allow blank fields in split times KLR,
 *  coded structure modified to introduce more subroutines
 */
public class SIEventLoader extends EventLoader {

    // various foreign options - add more as you find 'em!
    protected static final String FINISH_SYMBOLS = "A<F<Z<M";                          //$NON-NLS-1$
    protected static final String NUM_CONTROLS_SYMBOLS = "C<P";                        //$NON-NLS-1$
    protected static final String DSQ_SYMBOLS = "pm<mp<dnf<Felst.<Fehlst<Aufg<Zeit�b"; //$NON-NLS-1$
    protected static final String NON_COMP_SYMBOLS = "nc<aK<NC";                       //$NON-NLS-1$
    protected static final String KM_SYMBOLS = "km<m";                                 //$NON-NLS-1$
    protected static final String CLIMB_SYMBOLS = "Cm<Hm";                             //$NON-NLS-1$

    // line types
    protected static final int UNKNOWN = 0; // line unrecognised
    protected static final int COURSE_HEADER = 1;
    // course name, length [, climb, no. controls]
    protected static final int COURSE_INFO = 2; // list of control codes
    protected static final int COMP_FIRST = 3;
    // posn [, id], name [, class], total time, splits
    protected static final int NON_COMP_FIRST = 4;
    // aK|nc|NC [, id], name [, class], total time, splits
    protected static final int DSQ_FIRST = 5;
    // [id,] name [,class], mp|pm|Felst., splits
    protected static final int COMP_SECOND = 6; // club, splits
    protected static final int COMP_SUBSQ = 7; // splits

    // token types
    protected static final int STRING = 0;
    protected static final int FLOAT = 1;
    protected static final int INTEGER = 2;
    protected static final int TIME = 3;
    protected static final int KM = 4;
    protected static final int CLIMB = 5;
    protected static final int NUM_CONTROLS = 6;
    protected static final int NUM_COMPETITORS = 7;
    protected static final int CONTROL_CODE = 8;
    protected static final int FINISH = 9;
    protected static final int NON_COMP = 10;
    protected static final int MISPUNCH = 11;

    //input states
    protected static final int INITIAL = 100;
    protected static final int INFOF = 101;
    protected static final int INFOC = 102;
    protected static final int COMPTF = 103;
    protected static final int COMPSF = 104;
    protected static final int COMPTS = 105;
    protected static final int COMPSS = 106;
    protected static final int IGNORE = 107;

    // HTML defined special characters and Unicode equivalents
    protected static final String specialChars[] =
        {
            "&nbsp;", //$NON-NLS-1$
            "&iexcl;", //$NON-NLS-1$
            "&cent;", //$NON-NLS-1$
            "&pound;", //$NON-NLS-1$
            "&curren;", //$NON-NLS-1$
            "&yen;", //$NON-NLS-1$
            "&brvbar;", //$NON-NLS-1$
            "&sect;", //$NON-NLS-1$
            "&uml;", //$NON-NLS-1$
            "&copy;", //$NON-NLS-1$
            "&ordf;", //$NON-NLS-1$
            "&laquo;", //$NON-NLS-1$
            "&not;", //$NON-NLS-1$
            "&shy;", //$NON-NLS-1$
            "&reg;", //$NON-NLS-1$
            "&macr;", //$NON-NLS-1$
            "&deg;", //$NON-NLS-1$
            "&plusmn;", //$NON-NLS-1$
            "&sup2;", //$NON-NLS-1$
            "&sup3;", //$NON-NLS-1$
            "&acute;", //$NON-NLS-1$
            "&micro;", //$NON-NLS-1$
            "&para;", //$NON-NLS-1$
            "&middot", //$NON-NLS-1$
            "&cedil;", //$NON-NLS-1$
            "&sup1;", //$NON-NLS-1$
            "&ordm;", //$NON-NLS-1$
            "&raquo;", //$NON-NLS-1$
            "&frac14;", //$NON-NLS-1$
            "&frac12;", //$NON-NLS-1$
            "&frac34;", //$NON-NLS-1$
            "&iquest;", //$NON-NLS-1$
            "&Agrave;", //$NON-NLS-1$
            "&Aacute;", //$NON-NLS-1$
            "&Acirc;", //$NON-NLS-1$
            "&Atilde;", //$NON-NLS-1$
            "&Auml;", //$NON-NLS-1$
            "&Aring;", //$NON-NLS-1$
            "&AElig;", //$NON-NLS-1$
            "&Ccedil;", //$NON-NLS-1$
            "&Egrave;", //$NON-NLS-1$
            "&Eacute;", //$NON-NLS-1$
            "&Ecirc;", //$NON-NLS-1$
            "&Euml;", //$NON-NLS-1$
            "&Igrave;", //$NON-NLS-1$
            "&Iacute", //$NON-NLS-1$
            "&Icirc;", //$NON-NLS-1$
            "&Iuml;", //$NON-NLS-1$
            "&ETH;", //$NON-NLS-1$
            "&Ntilde;", //$NON-NLS-1$
            "&Ograve;", //$NON-NLS-1$
            "&Oacute;", //$NON-NLS-1$
            "&Ocirc;", //$NON-NLS-1$
            "&Otilde;", //$NON-NLS-1$
            "&Ouml;", //$NON-NLS-1$
            "&times;", //$NON-NLS-1$
            "&Oslash;", //$NON-NLS-1$
            "&Ugrave;", //$NON-NLS-1$
            "&Uacute;", //$NON-NLS-1$
            "&Ucirc;", //$NON-NLS-1$
            "&Uuml;", //$NON-NLS-1$
            "&Yacute;", //$NON-NLS-1$
            "&THORN;", //$NON-NLS-1$
            "&szlig;", //$NON-NLS-1$
            "&agrave;", //$NON-NLS-1$
            "&aacute;", //$NON-NLS-1$
            "&acirc;", //$NON-NLS-1$
            "&atilde;", //$NON-NLS-1$
            "&auml;", //$NON-NLS-1$
            "&aring;", //$NON-NLS-1$
            "&aelig;", //$NON-NLS-1$
            "&ccedil;", //$NON-NLS-1$
            "&egrave;", //$NON-NLS-1$
            "&eacute;", //$NON-NLS-1$
            "&ecirc;", //$NON-NLS-1$
            "&euml;", //$NON-NLS-1$
            "&igrave;", //$NON-NLS-1$
            "&iacute;", //$NON-NLS-1$
            "&icirc;", //$NON-NLS-1$
            "&iuml;", //$NON-NLS-1$
            "&eth;", //$NON-NLS-1$
            "&ntilde;", //$NON-NLS-1$
            "&ograve;", //$NON-NLS-1$
            "&oacute;", //$NON-NLS-1$
            "&ocirc;", //$NON-NLS-1$
            "&otilde;", //$NON-NLS-1$
            "&ouml;", //$NON-NLS-1$
            "&divide;", //$NON-NLS-1$
            "&oslash;", //$NON-NLS-1$
            "&ugrave;", //$NON-NLS-1$
            "&uacute;", //$NON-NLS-1$
            "&ucirc;", //$NON-NLS-1$
            "&uuml;", //$NON-NLS-1$
            "&yacute;", //$NON-NLS-1$
            "&thorn;", //$NON-NLS-1$
            "&yuml;", //$NON-NLS-1$
            "&quot;", //$NON-NLS-1$
            "&amp;", //$NON-NLS-1$
            "&lt;", //$NON-NLS-1$
            "&gt;", //$NON-NLS-1$
            "&OElig;", //$NON-NLS-1$
            "&oelig;", //$NON-NLS-1$
            "&Scaron;", //$NON-NLS-1$
            "&scaron;", //$NON-NLS-1$
            "&Yuml;", //$NON-NLS-1$
            "&circ;", //$NON-NLS-1$
            "&tilde;", //$NON-NLS-1$
            "&ensp;", //$NON-NLS-1$
            "&emsp;", //$NON-NLS-1$
            "&thinsp;", //$NON-NLS-1$
            "&zwnj;", //$NON-NLS-1$
            "&zwj;", //$NON-NLS-1$
            "&lrm;", //$NON-NLS-1$
            "&rlm;", //$NON-NLS-1$
            "&ndash;", //$NON-NLS-1$
            "&mdash;", //$NON-NLS-1$
            "&lsquo;", //$NON-NLS-1$
            "&rsquo;", //$NON-NLS-1$
            "&sbquo;", //$NON-NLS-1$
            "&ldquo;", //$NON-NLS-1$
            "&rdquo;", //$NON-NLS-1$
            "&bdquo;", //$NON-NLS-1$
            "&dagger;", //$NON-NLS-1$
            "&Dagger;", //$NON-NLS-1$
            "&permil;", //$NON-NLS-1$
            "&lsaquo;", //$NON-NLS-1$
            "&rsaquo;", //$NON-NLS-1$
            "&euro;" }; //$NON-NLS-1$

    protected static final char translatedChar[] =
        {
            '\u00a0',
            '\u00a1',
            '\u00a2',
            '\u00a3',
            '\u00a4',
            '\u00a5',
            '\u00a6',
            '\u00a7',
            '\u00a8',
            '\u00a9',
            '\u00aa',
            '\u00ab',
            '\u00ac',
            '\u00ad',
            '\u00ae',
            '\u00af',
            '\u00b0',
            '\u00b1',
            '\u00b2',
            '\u00b3',
            '\u00b4',
            '\u00b5',
            '\u00b6',
            '\u00b7',
            '\u00b8',
            '\u00b9',
            '\u00ba',
            '\u00bb',
            '\u00bc',
            '\u00bd',
            '\u00be',
            '\u00bf',
            '\u00c0',
            '\u00c1',
            '\u00c2',
            '\u00c3',
            '\u00c4',
            '\u00c5',
            '\u00c6',
            '\u00c7',
            '\u00c8',
            '\u00c9',
            '\u00ca',
            '\u00cb',
            '\u00cc',
            '\u00cd',
            '\u00ce',
            '\u00cf',
            '\u00d0',
            '\u00d1',
            '\u00d2',
            '\u00d3',
            '\u00d4',
            '\u00d5',
            '\u00d6',
            '\u00d7',
            '\u00d8',
            '\u00d9',
            '\u00da',
            '\u00db',
            '\u00dc',
            '\u00dd',
            '\u00de',
            '\u00df',
            '\u00e0',
            '\u00e1',
            '\u00e2',
            '\u00e3',
            '\u00e4',
            '\u00e5',
            '\u00e6',
            '\u00e7',
            '\u00e8',
            '\u00e9',
            '\u00ea',
            '\u00eb',
            '\u00ec',
            '\u00ed',
            '\u00ee',
            '\u00ef',
            '\u00f0',
            '\u00f1',
            '\u00f2',
            '\u00f3',
            '\u00f4',
            '\u00f5',
            '\u00f6',
            '\u00f7',
            '\u00f8',
            '\u00f9',
            '\u00fa',
            '\u00fb',
            '\u00fc',
            '\u00fd',
            '\u00fe',
            '\u00ff',
            '\u0022',
            '\u0026',
            '\u003c',
            '\u003e',
            '\u0152',
            '\u0153',
            '\u0160',
            '\u0161',
            '\u0178',
            '\u02c6',
            '\u02dc',
            '\u2002',
            '\u2003',
            '\u2009',
            '\u200c',
            '\u200d',
            '\u200e',
            '\u200f',
            '\u2013',
            '\u2014',
            '\u2018',
            '\u2019',
            '\u201a',
            '\u201c',
            '\u201d',
            '\u201e',
            '\u2020',
            '\u2021',
            '\u2030',
            '\u2039',
            '\u203a',
            '\u20ac' };

    protected int line = 0;
    protected String st = "", name = "", firstName = "", surname = "", club = ""; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$

    protected Vector tokens, refTokens;
    protected int refSkip = 0;

    Vector splits = new Vector(0, 1);
    protected BufferedReader reader;
    protected int numControls;
    protected int state = INITIAL;
    protected Course course;
    protected int splitNum, refNum;
    protected Time startTime = new Time(0, 0);

    public SIEventLoader(OEvent newEvent) {
        super(newEvent);
    }

    public void loadEvent(URL base, String fileName, boolean urlInput) throws IOException, Exception {
        numControls = 0;
        course = new Course(event);
        reader = openReader(base, fileName, urlInput);

        line = 0;
        try {
            st = getLine(reader);
            if (st == null)
                formatError(Messages.getString("SIEventLoader.No_data_140")); //$NON-NLS-1$
            while (st.trim() != null) {
                if (st == null)
                    return;
                // determine line type
                tokens = splitTokens(st);
                int linet = lineType(tokens);
                switch (linet) {
                    case COURSE_HEADER :
                        courseHeader();
                        break;
                    case COURSE_INFO :
                        courseInfo();
                        break;
                    case COMP_FIRST :
                        compFirst();
                        break;
                    case NON_COMP_FIRST :
                        state = IGNORE;
                        break;
                    case DSQ_FIRST : // ignore 'em!
                        state = IGNORE;
                        break;
                    case COMP_SECOND :
                        compSecond();
                        break;
                    case COMP_SUBSQ :
                        compMultipleLines();
                        break;
                    case UNKNOWN :
                        unknownLine();
                        break;
                }
                st = getLine(reader);
                if (st == null) {
                    return;
                }
            };
        } catch (Exception e) {
            throw (
                new IOException(
                    Messages.getString("SIEventLoader.Error_reading_SportIdent_HTML_file_around_line___141") //$NON-NLS-1$
                        + new Integer(line).toString()
                        + Messages.getString("SIEventLoader._n_in_Load_Event__n_142") //$NON-NLS-1$
                        + Messages.getString("SIEventLoader.Data___143") //$NON-NLS-1$
                        + st
                        + Messages.getString("SIEventLoader._n_n_Error___144") //$NON-NLS-1$
                        + e.toString()));
        }
    }

    protected void courseHeader() throws java.io.IOException {
        if (state == COMPTF || state == INITIAL || state == IGNORE) {
            int tNum = 0;
            name = ""; //$NON-NLS-1$
            while (((typeAt(tokens, tNum)) != FLOAT)
                && ((typeAt(tokens, tNum)) != NUM_COMPETITORS)
                && (tNum < tokens.size()))
                name = name.concat(" ").concat(stringAt(tokens, tNum++)).trim(); //$NON-NLS-1$
            name = translateChars(name);
            numControls = 0;
            state = INFOF;
        } else {
            formatError("Course Header"); //$NON-NLS-1$
        }
    }

    protected void courseInfo() throws java.io.IOException, java.lang.Exception {
        if (state == INFOF || state == INFOC) {
            if (state == INFOF) {
                refTokens = tokens;
            }
            int size = tokens.size();
            if (typeAt(tokens, size - 1) == FINISH) {
                state = COMPTF;
            } else {
                state = INFOC;
            }
            numControls = numControls + size;
            if (state == COMPTF) {
                numControls = numControls - 1;
                course = new Course(event, name, numControls);
            }
        } else if (state == IGNORE) {} else {
            formatError("Course Info"); //$NON-NLS-1$
        }
    }

    protected void compFirst() throws java.io.IOException {
        if (state == COMPTF || state == IGNORE) {
            // First set of for a result - either comp or non-comp
            // Extract the competitor name
            int firstTime = tokens.size() - 1;
            while (typeAt(tokens, firstTime) == TIME)
                firstTime--;
            int numSurnames = firstTime - 3;
            int fistNameIndex = 0;
            while (typeAt(tokens, fistNameIndex) == INTEGER || typeAt(tokens, fistNameIndex) == NON_COMP) {
                fistNameIndex++; //skip position, id, noncomp
            } 
            firstName = stringAt(tokens, fistNameIndex);
            // Why separate surname and First name
            surname = ""; 
            for (int i = fistNameIndex + 1; i <= firstTime; i++) {
                surname = surname.concat(" ").concat(stringAt(tokens, i)).trim(); //$NON-NLS-1$
            } 
            firstName = translateChars(firstName);
            surname = translateChars(surname);
            splitNum = 0;
            refNum = 0;
            state = COMPSF;
        } else {
            formatError("Comp First"); //$NON-NLS-1$
        }
    }

    protected void compSecond() throws java.lang.Exception {
        // get the club and first line of their split times
        if (state == COMPSF) {
            String s = ""; //$NON-NLS-1$
            int i = 0;
            int size = tokens.size();
            do {
                s = s.concat(stringAt(tokens, i));
                i++;
            } while (i < size && typeAt(tokens, i) != TIME);
            club = s;
            club = translateChars(club);
            addSplits(i--, size, refTokens.size() - refSkip);
            if (splitNum <= numControls) {
                state = COMPTS;
            } else {
                size = splits.size();
                Time[] splitResult;
                splitResult = new Time[size];
                for (int j = 0; j <= size - 1; j++) {
                    splitResult[j] = (Time) splits.elementAt(j);
                }
                //splits.clear();
                splits.removeAllElements();
                Result result = new Result(firstName, surname, club, course, startTime, splitResult);
                state = COMPTF;
            }
        } else if (state == INITIAL || state == IGNORE || state == COMPTF) {
            //ignore line
        } else {
            formatError("Comp Second"); //$NON-NLS-1$
        }
    }

    protected void compMultipleLines() throws java.lang.Exception {
        int trail;
        int refSize = refTokens.size() - refSkip;
        int tokensSize = tokens.size();
        if (state == COMPTS) {
            state = COMPSS; //ignore first line
        } else if (state == COMPSS) {
            if ((splitNum + refSize) < numControls) {
                trail = refSize;
            } else {
                trail = numControls - splitNum + 1;
            }
            addSplits(0, tokensSize, trail);
            if (splitNum < numControls) {
                state = COMPTS; //process more line pairs
            } else {
                Time[] splitResult;
                int size = splits.size();
                splitResult = new Time[size];
                for (int j = 0; j <= size - 1; j++) {
                    splitResult[j] = (Time) splits.elementAt(j);
                }
                splits.removeAllElements();
                Result result = new Result(firstName, surname, club, course, startTime, splitResult);
                state = COMPTF;
            }
        }
    }

    protected void unknownLine() throws java.io.IOException {
        if (state == INITIAL) {
            // ignore
        } else {
            formatError("Unknown line"); //$NON-NLS-1$
        }
    }

    protected void addSplits(int first, int last, int trail) throws java.lang.Exception {
        int refNum = 0;
        int i;
        for (i = first; i < last; i++) {
            if ((typeAt(tokens, i) == TIME) && (splitNum <= numControls)) {
                //Add invalid time for blank cols before this split
                while (colAt(refTokens, refNum + refSkip) < colAt(tokens, i)) {
                    splits.addElement(new Time(0, false));
                    splitNum++;
                    refNum++;
                } //while
                splits.addElement(parseSplit(stringAt(tokens, i)));
                splitNum++;
                refNum++;
            }
        }
        //add invalid time for blank cols at end of line
        while (refNum < trail && (splitNum <= numControls)) {
            splits.addElement(new Time(0, false));
            splitNum++;
            refNum++;
        }
    }

    protected void formatError(String s) throws java.io.IOException {
        throw (
            new IOException(
                Messages.getString("SIEventLoader.Error_reading_SportIdent_HTML_file_around_line___155") //$NON-NLS-1$
                    + new Integer(line).toString()
                    + Messages.getString("SIEventLoader._n_in__156") //$NON-NLS-1$
                    + s
                    + Messages.getString("SIEventLoader._n_Data___157") //$NON-NLS-1$
                    + st
                    + Messages.getString("SIEventLoader._n_n_Error___158"))); //$NON-NLS-1$
    }

    protected String getLine(BufferedReader reader) throws IOException {
        // Read the next non-blank line - stripping the HTML tags
        String buffer;
        do {
            buffer = reader.readLine();
            line++;
            if (buffer == null)
                return buffer;
            buffer = StripHTMLTags(buffer, reader);
        } while (buffer.trim().length() == 0);
        return (buffer);
    }

    protected String StripHTMLTags(String buffer, BufferedReader reader) throws IOException {
        // Strips the HTML tags from a string
        // If a tag spans a line an extra line is read
        int tagStart;
        while ((tagStart = buffer.indexOf("<")) != -1) { //$NON-NLS-1$
            int tagEnd;
            try {
                // Read an extra line it the
                while ((tagEnd = buffer.indexOf(">", tagStart)) == -1) { //$NON-NLS-1$
                    buffer = buffer.concat(" ".concat(reader.readLine())); //$NON-NLS-1$
                    line++;
                } 
                String beforeTag = (tagStart > 0) ? buffer.substring(0, tagStart) : ""; //$NON-NLS-1$
                String afterTag = (tagEnd < buffer.length()) ? buffer.substring(tagEnd + 1, buffer.length()) : ""; //$NON-NLS-1$
                buffer = beforeTag.concat(afterTag);
            } 
            catch (Exception e) {
                throw new IOException(Messages.getString("SIEventLoader.Error_removing_HTML_tags_164")); //$NON-NLS-1$
            }
        }
        return (buffer);
    }

    protected int lineType(Vector tokens) {
        //returns a line type (integer) constant describing the line
        Token t;
        String s;
        int last = tokens.size() - 1;
        int firstType = typeAt(tokens, 0);
        int lastType = typeAt(tokens, last);
        if ((lastType == NUM_CONTROLS) || (lastType == KM))
            return COURSE_HEADER;
        if ((last >= 1) && (typeAt(tokens, last - 1) == CONTROL_CODE) || (last == 0 && lastType == FINISH))
            return COURSE_INFO;
        if (isDisqualified(tokens))
            return DSQ_FIRST;
        if ((last >= 2) && (firstType == INTEGER) && (lastType == TIME))
            return COMP_FIRST;
        if ((last >= 0) && (firstType == NON_COMP))
            return NON_COMP_FIRST;
        if ((last >= 0) && (firstType == STRING))
            return COMP_SECOND;
        if (firstType == TIME)
            return COMP_SUBSQ;
        return (UNKNOWN);
    }
    
    protected boolean isDisqualified(Vector tokens) {
        // true iff first time is preceeded by misspunch
        // will be in error if last name is misspinch token!
        int mispunchIndex = tokens.size();
        int type;
        if (mispunchIndex == 0)
            return (false);
        do {
            mispunchIndex--;
            type = typeAt(tokens, mispunchIndex);
        } while ((mispunchIndex > 0) && (type == TIME));
        return (type == MISPUNCH);
    }

    protected boolean isDisqualifiedOLd(int[] tokenTypes) {
        // true iff first time is preceeded by misspunch
        // will be in error if last name is misspinch token!
        int mispunchIndex = tokenTypes.length;

        if (tokenTypes.length == 0) {
            return (false);
        }

        do {
            mispunchIndex--;
        } while ((mispunchIndex > 0) && (tokenTypes[mispunchIndex] == TIME));

        return (tokenTypes[mispunchIndex] == MISPUNCH);
    }

    protected int tokenType(String token) {
        // return an integer constant describing the token
        try {
            if (KM_SYMBOLS.indexOf(token) != -1)
                return (KM);
            if ((token.length() == 2) && (CLIMB_SYMBOLS.indexOf(token) != -1))
                return (CLIMB);
            if (NUM_CONTROLS_SYMBOLS.indexOf(token) != -1)
                return (NUM_CONTROLS);
            if (token.indexOf("(") != -1) { //$NON-NLS-1$
                if ("0123456789".indexOf(token.substring(0, 1)) != -1) //$NON-NLS-1$
                    return (CONTROL_CODE);
                if ("0123456789".indexOf(token.substring(1, 1)) != -1) //$NON-NLS-1$
                    return (NUM_COMPETITORS);
            }
            if ((token.length() == 1) && (FINISH_SYMBOLS.indexOf(token) != -1))
                return (FINISH);
            if (NON_COMP_SYMBOLS.indexOf(token) != -1)
                return (NON_COMP);
            if ((token.length() >= 1) && (DSQ_SYMBOLS.indexOf(token) != -1))
                return (MISPUNCH);
            if (((token.indexOf(":") != -1) && ("0123456789".indexOf(token.substring(0, 1)) != -1)) //$NON-NLS-1$ //$NON-NLS-2$
                || (token.indexOf("---") != -1) //$NON-NLS-1$
                || (token.indexOf("--:--") != -1) //$NON-NLS-1$
                || (token.charAt(0) == '*')
                || (token.equals("0.00"))) //$NON-NLS-1$
                return (TIME);
            if ((token.indexOf(".") != -1) && ((new Float(token).floatValue()) > 0)) //$NON-NLS-1$
                return (FLOAT);
            if ((Integer.parseInt(token)) > 0)
                return (INTEGER);
        } catch (NumberFormatException e) {
            return (STRING);
        }
        return (STRING);
    }

    protected Time parseSplit(String split) throws Exception {
        // parse a Split token (hh:mm:ss or mm:ss) and return the time it represents
        // times prefixed by * indicating

        String hourString, minString, secString;
        int firstSep, lastSep;

        if ((split.indexOf("-----") != -1) //$NON-NLS-1$
            || (split.indexOf("--:--") != -1) //$NON-NLS-1$
            || (split.indexOf("*") != -1) //$NON-NLS-1$
            || (split.trim() == "0.00")) { //$NON-NLS-1$
            return (new Time(0, false));
        } else {
            try {
                if ((firstSep = split.indexOf(":")) == (lastSep = split.lastIndexOf(":"))) { //$NON-NLS-1$ //$NON-NLS-2$
                    //  mmm:ss format
                    minString = split.substring(0, firstSep);
                    secString = split.substring(firstSep + 1);
                    return (new Time(Integer.parseInt(minString), Integer.parseInt(secString)));
                } else {
                    //  hh:mm:ss format
                    hourString = split.substring(0, firstSep);
                    minString = split.substring(firstSep + 1, lastSep - firstSep);
                    secString = split.substring(lastSep + 1);
                    int hourInt = Integer.parseInt(hourString);
                    int minInt = Integer.parseInt(minString);
                    minInt = minInt + (60 * hourInt);
                    return (new Time(minInt, Integer.parseInt(secString)));
                }
            } catch (NumberFormatException e) {
                throw (new Exception(Messages.getString("SIEventLoader.Bad_split_format___180").concat(split))); //$NON-NLS-1$
            }
        }
    }

    protected static String translateChars(String buffer) {
        // strip HTML representations of 'special' chars and replace with chars

        String returnString = buffer;
        int charStart, charEnd, charCode;
        String beforeChar, afterChar, charNum;
        Character newChar;

        // first look for &#nnn; or &#xnnnn etc. representation
        // and convert these to characters
        try {
            while ((charStart = returnString.indexOf("&#")) != -1) { //$NON-NLS-1$
                if (charStart != 0) {
                    beforeChar = returnString.substring(0, charStart);
                } else {
                    beforeChar = ""; //$NON-NLS-1$
                }
                charEnd = returnString.indexOf(";", charStart); //$NON-NLS-1$
                if ((charEnd == -1) || (charEnd > (charStart + 8))) {
                    charEnd = returnString.indexOf(" ", charStart); //$NON-NLS-1$
                }
                charNum = returnString.substring(charStart + 2, charEnd);
                afterChar = returnString.substring(charEnd + 1, returnString.length());
                if (charNum.indexOf("x") != -1) { //$NON-NLS-1$
                    charCode = Integer.decode("0".concat(charNum)).intValue(); //$NON-NLS-1$
                } else {
                    charCode = Integer.decode(charNum).intValue();
                }
                newChar = new Character((char) charCode);
                returnString = beforeChar.concat(newChar.toString()).concat(afterChar);
            }
        } catch (Exception e) {
            // leave the string unaltered & assume it's just dodgy html char encoding
        }

        // next do the defined 'specials'
        for (int i = 0; i < specialChars.length; i++) {
            while ((charStart = returnString.indexOf(specialChars[i])) != -1) {
                if (charStart != 0) {
                    beforeChar = returnString.substring(0, charStart);
                } else {
                    beforeChar = ""; //$NON-NLS-1$
                }
                afterChar = returnString.substring(charStart + specialChars[i].length(), returnString.length());
                returnString = beforeChar.concat(new Character(translatedChar[i]).toString()).concat(afterChar);
            }
        }
        return (returnString);
    }

    protected Token sub(String buffer, int start) {
        int s = start;
        int e;
        String w;
        while (s < buffer.length() && buffer.charAt(s) == ' ')
            s++;
        if (s == buffer.length()) {
            return new Token("", s, STRING); //$NON-NLS-1$
        }
        e = s;
        while (e < buffer.length() && buffer.charAt(e) != ' ')
            e++;
        start = e;
        w = buffer.substring(s, e);
        return new Token(w, e, tokenType(w));
    }

    protected Vector splitTokens(String buffer) {
        // breaks down buffer by spaces and returns vector of tokens
        Vector Tokens = new Vector(0, 1);
        int start = 0;
        Token t;
        boolean notDone = true;
        while (start < buffer.length() && notDone) {
            t = sub(buffer, start);
            if (t.value != "") { //$NON-NLS-1$
                Tokens.addElement(t);
                start = t.end;
            } else
                notDone = false;
        }
        return Tokens;
    }

    protected String stringAt(Vector v, int i) {
        Token t = (Token) v.elementAt(i);
        return t.value;
    }

    protected int typeAt(Vector v, int i) {
        Token t = (Token) v.elementAt(i);
        return t.type;
    }

    protected int colAt(Vector v, int i) {
        Token t = (Token) v.elementAt(i);
        return t.end;
    }

}