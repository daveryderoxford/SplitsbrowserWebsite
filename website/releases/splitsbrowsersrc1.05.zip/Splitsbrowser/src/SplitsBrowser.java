/*
 *    SplitsBrowser - SplitsBrowser Applet.
 *
 *    Copyright (C) 2000  Dave Ryder
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this library; see the file COPYING.  If not, write to
 *    the Free Software Foundation, Inc.,show 59 Temple Place - Suite 330,
 *    Boston, MA 02111-1307, USA.
 */

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.io.*;

//import orienteering.splitsbrowser.model.*;
//import orienteering.splitsbrowser.view.*;

/**
 * Java Applet for displaying orienteering split time graphically
 * Currently includes two views. A progress-o-gram view which is
 * well developed and a text view.
 *
 * @author <b>Dave Ryder</b>
 */
public class SplitsBrowser extends Applet implements Runnable {

    // Initialize the applet
    public void init() {

        try {
            jbInit();
        } catch (Exception e) {
            showError(e, Messages.getString("SplitsBrowser.Error_initialising_application_1")); //$NON-NLS-1$
        }

        try {
            splitsGraph.setColor1(
                getColorParameter("color1", splitsGraph.getColor1())); //$NON-NLS-1$
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            splitsGraph.setColor2(
                getColorParameter("color2", splitsGraph.getColor2())); //$NON-NLS-1$
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            Color c =
                getColorParameter("background", splitsGraph.getBackground()); //$NON-NLS-1$
            this.setBackground(c);

            // Set all the elements of the top panel
            topPanel.setBackground(c);
            classLabel.setBackground(c);
            compareAgainstLabel.setBackground(c);
            viewLabel.setBackground(c);
            graphPanel.setBackground(c);
            textPanel.setBackground(c);
            msgPanel.setBackground(c);
            msgTextArea.setBackground(c);

            bottomPanel.setBackground(c);
            splitTimeChk.setBackground(c);
            timeBehindChk.setBackground(c);
            totalTimeChk.setBackground(c);
            versionLabel.setBackground(c);
            versionLabel.setText("Splitsbrowser v" + About.VERSION); //$NON-NLS-1$
           
            this.repaint();

        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            splitsGraph.setBackground(
                getColorParameter("graphbackground", splitsGraph.getColor2())); //$NON-NLS-1$
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            inputFormat =
                Integer.parseInt(this.getParameter("dataformat", "0")); //$NON-NLS-1$ //$NON-NLS-2$
            System.out.println(
                Messages.getString("SplitsBrowser.input_format_9") + Integer.toString(inputFormat) + "\n"); //$NON-NLS-1$ //$NON-NLS-2$
        } catch (Exception e) {
            showError(
                e,
                Messages.getString("SplitsBrowser.Error_reading_data_format_parameter.__n_An_integer_value_must_be_specified_11")); //$NON-NLS-1$
        }

        try {
            inputFilename = this.getParameter(Messages.getString("SplitsBrowser.inputdata_12"), Messages.getString("SplitsBrowser.No_Course_data_13")); //$NON-NLS-1$ //$NON-NLS-2$

        } catch (Exception e) {
            showError(e, Messages.getString("SplitsBrowser.Error_reading_zipped_parameter_14")); //$NON-NLS-1$
        }
    }

    public void run() {
        runner.yield();

        showMessage(
            Messages.getString("SplitsBrowser._n__Loading_event_data_from_file__15") + inputFilename + "...\n"); //$NON-NLS-1$ //$NON-NLS-2$
        try {
            loadEvent(inputFilename, inputFormat);
            setEventTimeAlgorithm(OptimumTimeAlgorithms.fastest);
            compareAgainstChoice.select(Messages.getString("SplitsBrowser.Fastest_time_17")); //$NON-NLS-1$
            hideMessage();
        } catch (Exception e) {
            getAppletContext().showStatus(Messages.getString("SplitsBrowser.Error_reading_input_file_18")); //$NON-NLS-1$
            showError(e, Messages.getString("SplitsBrowser.Error_reading_input_file_19")); //$NON-NLS-1$
        }

        graphPanel.validate();
    }

    public void loadEvent(String inputFilename, int inputFormat)
        throws IOException, Exception {
        OEvent newEvent = null;

        newEvent = new OEvent(""); //$NON-NLS-1$

        if (inputFormat == SI_HTML_INPUT_FORMAT) {
            System.out.println(Messages.getString("SplitsBrowser.Creating_SI_event_loader_21")); //$NON-NLS-1$
            loader = new SIEventLoader(newEvent);
        } else if (inputFormat == ABM_HTML_INPUT_FORMAT) {
            System.out.println(Messages.getString("SplitsBrowser.Creating_ABM_event_loader_22")); //$NON-NLS-1$
            loader = new ABMEventLoader(newEvent);
        } else {
            System.out.println(Messages.getString("SplitsBrowser.Creating_CSV_event_loader_23")); //$NON-NLS-1$
            loader = new EventLoader(newEvent);
        }

        // Load from a file for local testing
        if (isStandalone) {
            loader.loadEvent(null, inputFilename, false);
        } else {
            loader.loadEvent(getDocumentBase(), inputFilename, true);
        }

        Course course = newEvent.getCourse(0);
        setEvent(newEvent);
        splitsGraph.setCourse(course);
    }

    public void setSize(int width, int height) {
        /* The setsize method is overwriden to get the applet to
        		resize in the browser */
        super.setSize(width, height);
        validate();
    }

    public void setEvent(OEvent newEvent) {
        event = newEvent;
        classChoice.removeAll();
        resultsList.removeAll();

        // Load the classes - calculating the max size of the
        int maxSize = Integer.MIN_VALUE;
        FontMetrics fontMetrics =
            classChoice.getFontMetrics(classChoice.getFont());

        for (int i = 0; i < event.getNumCourses(); i++) {
            String name = event.getCourse(i).getName();
            classChoice.add(name);
            maxSize = Math.max(maxSize, fontMetrics.stringWidth(name));
        }

        // Resize the choice to the max string size
        int buttonSize = 25;
        classChoice.setSize(maxSize + buttonSize, 0);

        topPanel.invalidate();

        splitsGraph.setCourse(null);
        splitsTable.setCourse(null);

        // Select the first course in the list
        classChoice.select(0);

        classChoice_itemStateChanged(null);
    }

    public void setCourse(Course newCourse) {
        // Update the course selection
        classChoice.select(newCourse.getName());
    }

    //Component initialization

    private void jbInit() throws Exception {

        // Sizes and layouts
        this.setLayout(borderLayout1);
        topPanel.setLayout(topPanelLayout);
        this.setFont(new java.awt.Font("Dialog", 0, 11)); //$NON-NLS-1$
        this.setSize(new Dimension(472, 478));
        topPanelLayout.setHgap(3);
        topPanelLayout.setAlignment(0);
        topPanelLayout.setVgap(6);
        mainPanel.setLayout(mainPanelCardLayout);

        // Properties
        classLabel.setAlignment(1);
        classLabel.setText(Messages.getString("SplitsBrowser.Class_25")); //$NON-NLS-1$
        classChoice.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                classChoice_itemStateChanged(e);
            }
        });

        viewLabel.setAlignment(1);
        viewLabel.setText(Messages.getString("SplitsBrowser._View_26")); //$NON-NLS-1$
        viewChoice.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                viewChoice_itemStateChanged(e);
            }
        });
        
        graphPanel.setLayout(borderLayout2);
        compareAgainstLabel.setAlignment(1);
        compareAgainstLabel.setText(Messages.getString("SplitsBrowser.Compare_against_27")); //$NON-NLS-1$
        borderLayout1.setVgap(3);
        borderLayout2.setHgap(6);
        splitsGraph.setLayout(borderLayout3);
        resultsList.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(ActionEvent e) {
                resultsList_actionPerformed(e);
            }
        });
        resultsList.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                resultsList_itemStateChanged(e);
            }
        });
        compareAgainstChoice
            .addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                compareAgainstChoice_itemStateChanged(e);
            }
        });
        splitsTable.setBackground(Color.white);
        borderLayout3.setVgap(5);
        borderLayout3.setHgap(5);
        bottomPanel.setLayout(borderLayout6);

        timeBehindChk.setState(false);
        timeBehindChk.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                timeBehindChk_itemStateChanged(e);
            }
        });

        totalTimeChk.setState(false);
        totalTimeChk.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                totalTimeChk_itemStateChanged(e);
            }
        });

        splitTimeChk.setState(true);
        splitTimeChk.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(ItemEvent e) {
                splitTimeChk_itemStateChanged(e);
            }
        });

        splitTimeChk.setLabel(Messages.getString("SplitsBrowser.Split_times_28")); //$NON-NLS-1$
        timeBehindChk.setLabel(Messages.getString("SplitsBrowser.Time_behind_29")); //$NON-NLS-1$
        totalTimeChk.setLabel(Messages.getString("SplitsBrowser.Total_time_30")); //$NON-NLS-1$
        msgPanel.setLayout(borderLayout4);
        msgTextArea.setBackground(Color.lightGray);
        msgTextArea.setFont(new java.awt.Font("SansSerif", 0, 12)); //$NON-NLS-1$
        msgTextArea.setRows(100);
        msgTextArea.setText("textArea1"); //$NON-NLS-1$
        textPanel.setLayout(borderLayout5);
        textPanel.setBackground(Color.white);
        topPanel.setVisible(false);
        bottomPanelEast.setLayout(flowLayout1);
        bottomWestPanel.setLayout(flowLayout2);
        versionLabel.setText(" Splitsbrowser"); //$NON-NLS-1$
        this.add(topPanel, BorderLayout.NORTH);

        viewChoice.add(VIEW_DIFFERENCE_GRAPH);
        viewChoice.add(VIEW_TABLE);

        compareAgainstChoice.add(Messages.getString("SplitsBrowser.Winner_34")); //$NON-NLS-1$
        compareAgainstChoice.add(Messages.getString("SplitsBrowser.Fastest_time_35")); //$NON-NLS-1$
        compareAgainstChoice.add(Messages.getString("SplitsBrowser.Fastest_time_+_5%_36")); //$NON-NLS-1$
        compareAgainstChoice.add(Messages.getString("SplitsBrowser.Fastest_time_+_25%_37")); //$NON-NLS-1$
        compareAgainstChoice.add(Messages.getString("SplitsBrowser.Fastest_time_+_50%_38")); //$NON-NLS-1$
        compareAgainstChoice.add(Messages.getString("SplitsBrowser.Fastest_time_+_75%_39")); //$NON-NLS-1$
        compareAgainstChoice.add(Messages.getString("SplitsBrowser.Fastest_time_+_100%_40")); //$NON-NLS-1$
        
        // Add components
        topPanel.add(classLabel, null);
        topPanel.add(classChoice, null);
        topPanel.add(viewLabel, null);
        topPanel.add(viewChoice, null);
        topPanel.add(compareAgainstLabel, null);
        topPanel.add(compareAgainstChoice, null);
        this.add(mainPanel, BorderLayout.CENTER);

        mainPanel.add(msgPanel, "msgPanel"); //$NON-NLS-1$
        msgPanel.add(msgTextArea, BorderLayout.CENTER);

        mainPanel.add(graphPanel, "graphPanel"); //$NON-NLS-1$
        graphPanel.add(resultsList, BorderLayout.WEST);
        graphPanel.add(splitsGraph, BorderLayout.CENTER);

        mainPanel.add(textPanel, "textPanel"); //$NON-NLS-1$
        textPanel.add(splitsTable, BorderLayout.CENTER);

        this.add(bottomPanel, BorderLayout.SOUTH);
        bottomPanel.add(bottomWestPanel, BorderLayout.CENTER);
        bottomPanel.add(bottomPanelEast, BorderLayout.EAST);
        bottomPanelEast.add(totalTimeChk, null);
        bottomPanelEast.add(splitTimeChk, null);
        bottomPanelEast.add(timeBehindChk, null);
        bottomPanel.add(versionLabel, BorderLayout.WEST);

    }

    // Start the applet
    public void start() {
        if (runner == null) {
            runner = new Thread(this);
            runner.start();
        } else if (runner.isAlive()) {
            runner.resume();
        }
    }

    // Stop the applet
    public void stop() {
        if ((runner != null) && runner.isAlive()) {
            runner.suspend();
        }
    }

    // Destroy the applet

    public void destroy() {
        runner.yield();
    }

    // Get Applet information
    public String getAppletInfo() {
        return "SplitsBrowser"; //$NON-NLS-1$
    }

    void viewChoice_itemStateChanged(ItemEvent e) {
        updateViewShown();
    }

    private void updateViewShown() {
        String str = viewChoice.getSelectedItem();

        try {
            if (str == VIEW_DIFFERENCE_GRAPH) {
                mainPanelCardLayout.show(mainPanel, "graphPanel"); //$NON-NLS-1$
                splitsGraph.setGraphType(splitsGraph.GRAPH_TYPE_COMPARISON);
            } else if (str == VIEW_ACTUAL_TIME) {
                mainPanelCardLayout.show(mainPanel, "graphPanel"); //$NON-NLS-1$
                splitsGraph.setGraphType(splitsGraph.GRAPH_TYPE_RACE);
            } else if (str == VIEW_TABLE) {
                mainPanelCardLayout.show(mainPanel, "textPanel"); //$NON-NLS-1$
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    void compareAgainstChoice_itemStateChanged(ItemEvent e) {
        // Change the comparison algorithm

        // Set the optimum time algorithm for all the courses
        switch (compareAgainstChoice.getSelectedIndex()) {
            case -1 :
                break;
            case 0 :
                setEventTimeAlgorithm(OptimumTimeAlgorithms.winner);
                break;
            case 1 :
                setEventTimeAlgorithm(OptimumTimeAlgorithms.fastest);
                break;
            case 2 :
                OptimumTimeAlgorithms.percentBehind.setPercentBehind(5);
                setEventTimeAlgorithm(OptimumTimeAlgorithms.percentBehind);
                break;
            case 3 :
                OptimumTimeAlgorithms.percentBehind.setPercentBehind(25);
                setEventTimeAlgorithm(OptimumTimeAlgorithms.percentBehind);
                break;
            case 4 :
                OptimumTimeAlgorithms.percentBehind.setPercentBehind(50);
                setEventTimeAlgorithm(OptimumTimeAlgorithms.percentBehind);
                break;
            case 5 :
                OptimumTimeAlgorithms.percentBehind.setPercentBehind(75);
                setEventTimeAlgorithm(OptimumTimeAlgorithms.percentBehind);
                break;
            case 6 :
                OptimumTimeAlgorithms.percentBehind.setPercentBehind(100);
                setEventTimeAlgorithm(OptimumTimeAlgorithms.percentBehind);
                break;
            default :
                break;
        }

        splitsGraph.invalidateDimensions();
        splitsTable.setCourse(currentCourse);
    }

    void classChoice_itemStateChanged(ItemEvent e) {
        // Find the course
        if (classChoice.getSelectedIndex() == -1)
            return;

        currentCourse = event.getCourse(classChoice.getSelectedIndex());

        splitsGraph.setCourse(currentCourse);
        splitsTable.setCourse(currentCourse);

        //  Update the results list
        resultsList.setVisible(false);
        resultsList.removeAll();

        for (int i = 0; i < currentCourse.getNumResults(); i++) {
            resultsList.add(currentCourse.getResult(i).getFullName());
        }

        resultsList.setVisible(true);
    }

    void resultsList_itemStateChanged(ItemEvent e) {
        // Find the result we have selected
        Integer index = (Integer) e.getItem();
        lastIndex = index.intValue();

        if (index.intValue() != -1) {

            Result theResult = currentCourse.getResult(index.intValue());

            if (e.getStateChange() == ItemEvent.SELECTED) {
                splitsGraph.displayResult(theResult);
            } else {
                splitsGraph.removeResult(theResult);
            }
        }
    }

    public Insets insets() {
        return this.insets;
    }

    void resultsList_actionPerformed(ActionEvent e) {
        // Double click handler - a bodge to get round a bug where
        // double clicking on a selected item leaves it selected
        // but only generates a single selection event

        Result theResult = currentCourse.getResult(lastIndex);
        if (splitsGraph.isDisplayed(theResult)) {
            resultsList.select(lastIndex);
        } else {
            resultsList.deselect(lastIndex);
        }
    }

    void splitTimeChk_itemStateChanged(ItemEvent e) {
        splitsGraph.setShowSplits(e.getStateChange() == e.SELECTED);
        splitsTable.setShowSplits(e.getStateChange() == e.SELECTED);
    }

    void timeBehindChk_itemStateChanged(ItemEvent e) {
        splitsGraph.setShowTimeBehind(e.getStateChange() == e.SELECTED);
    }

    void totalTimeChk_itemStateChanged(ItemEvent e) {
        splitsGraph.setShowTotalTime(e.getStateChange() == e.SELECTED);
    }

    // Get a parameter value
    private String getParameter(String key, String def) {
        return isStandalone
            ? System.getProperty(key, def)
            : (getParameter(key) != null ? getParameter(key) : def);
    }

    private void showError(Exception e, String msg) {
        // Show the message
        showMessage(msg + "\n" + e.toString()); //$NON-NLS-1$
        e.printStackTrace();
    }

    private void showMessage(String s) {
        topPanel.setVisible(false);
        mainPanelCardLayout.show(mainPanel, "msgPanel"); //$NON-NLS-1$
        msgTextArea.setText(s);
        this.validate();
    }

    private void hideMessage() {
        topPanel.setVisible(true);
        updateViewShown();
        // Force a layout on all components
        this.validate();
    }

    private Color getColorParameter(String paramName, Color defaultColor) {
        final String hexPrefix = "0x"; //$NON-NLS-1$

        // Gets a color parameter in web format of hex
        String str = getParameter(paramName, "").trim(); //$NON-NLS-1$

        // exit if the parameter was not set
        if (str.length() == 0) {
            return (defaultColor);
        }

        // ignore a # character on the start of the string as used in HTML
        int start = 0;
        if (str.startsWith("#")) { //$NON-NLS-1$
            start = 1;
        }

        Integer red = new Integer(0);
        String s = hexPrefix + str.substring(start, start + 2);
        red = Integer.decode(s);

        Integer green = new Integer(0);
        green = Integer.decode(hexPrefix + str.substring(start + 2, start + 4));

        Integer blue = new Integer(0);
        blue = Integer.decode(hexPrefix + str.substring(start + 4, start + 6));

        return (new Color(red.intValue(), green.intValue(), blue.intValue()));
    }

    private void setEventTimeAlgorithm(
        OptimumTimeAlgorithms.IOptimumTimeAlgorithm algorithm) {
        for (int i = 0; i < event.getNumCourses(); i++) {
            event.getCourse(i).setOptimumTimeAlgorithm(algorithm);
        }
    }

    // Shared in package for testing
    public static final int SI_HTML_INPUT_FORMAT = 1;
    public static final int ABM_HTML_INPUT_FORMAT = 2;

    protected Insets insets = new Insets(7, 7, 7, 7);

    EventLoader loader = null;

    // Visual controls
    Panel topPanel = new Panel();
    Panel mainPanel = new Panel();
    FlowLayout topPanelLayout = new FlowLayout();
    Label classLabel = new Label();
    Choice classChoice = new Choice();
    Label viewLabel = new Label();
    Choice viewChoice = new Choice();
    CardLayout mainPanelCardLayout = new CardLayout();
    Panel graphPanel = new Panel();
    Panel textPanel = new Panel();

    Label compareAgainstLabel = new Label();
    BorderLayout borderLayout1 = new BorderLayout();
    List resultsList = new List(1, true); // Allow multi select
    BorderLayout borderLayout2 = new BorderLayout();
    Choice compareAgainstChoice = new Choice();
    SplitsGraph splitsGraph = new SplitsGraph();
    SplitsTable splitsTable = new SplitsTable();
    BorderLayout borderLayout3 = new BorderLayout();
    Panel bottomPanel = new Panel();
    Checkbox splitTimeChk = new Checkbox();
    Checkbox timeBehindChk = new Checkbox(Messages.getString("SplitsBrowser.Time_behind_53"), false); //$NON-NLS-1$
    Checkbox totalTimeChk = new Checkbox();
    Panel msgPanel = new Panel();

    boolean isStandalone = false; // Are we running as an applet or application
    private int lastIndex = -1; // Last index selected in the
    protected OEvent event = null; // Current event
    protected Course currentCourse = null; // Current course

    // Local property variables
    private String name;
    private String color1;
    private String color2;
    private String backgroundColor;
    private String courseData;
    private Thread runner = null;
    private int inputFormat;
    private String inputFilename;
    private static String VIEW_DIFFERENCE_GRAPH = Messages.getString("SplitsBrowser.Time_difference_graph_54"); //$NON-NLS-1$
    private static String VIEW_TABLE = Messages.getString("SplitsBrowser.Results_table_55"); //$NON-NLS-1$
    private static String VIEW_ACTUAL_TIME = Messages.getString("SplitsBrowser.Actual_time_graph_56"); //$NON-NLS-1$
    private Color backGroundColor = Color.gray;
    TextArea msgTextArea = new TextArea("", 10, 10, TextArea.SCROLLBARS_NONE); //$NON-NLS-1$
    BorderLayout borderLayout4 = new BorderLayout();
    BorderLayout borderLayout5 = new BorderLayout();
    BorderLayout borderLayout6 = new BorderLayout();
    Panel bottomWestPanel = new Panel();
    Panel bottomPanelEast = new Panel();
    FlowLayout flowLayout1 = new FlowLayout();
    FlowLayout flowLayout2 = new FlowLayout();
    Label versionLabel = new Label();

}