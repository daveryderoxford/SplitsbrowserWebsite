/*
 *    SplitsBrowser - eTiming - n3Sport CVS format loader.
 *
 *    Original Copyright (C) 2002  Dave Ryder
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this library; see the file COPYING.  If not, write to
 *    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 *    Boston, MA 02111-1307, USA.
 */

import java.io.*;
import java.util.*;
import java.net.*;
import java.util.zip.*;

/**
 * Loads event details from an SI .html file 
 * */
public class EmitCVSEventLoader extends EventLoader {

    private static final char EVENT = 'R';
    private static final char CLASS = 'C';
    private static final char COMPETITOR = 'I';
    private static final char SPLITS = 'S';
    private static final char END = 'E';

    private int lineCount = 0;

    public EmitCVSEventLoader(OEvent newEvent) {
        super(newEvent);
    }

    private String getLine(BufferedReader reader) throws IOException {
        String buffer;
        do {
            buffer = reader.readLine();
            lineCount++;
            if (buffer == null)
                return buffer;
        } while (buffer.trim().length() == 0);
        return (buffer);
    }

    private String getString(StringTokenizer st) {
        String s = st.nextToken().trim();
        // Remove quotes 
        //   if (s.startsWith("\"")) s=s.toCharArray()

        return (s);

    }

    private float getFloat(StringTokenizer st) {
        String s = st.nextToken().trim();
        if (s == null || s.length() == 0) {
            return ((float) 0.0);
        } else {
            return (Float.parseFloat(s));
        }
    }

    private int getInt(StringTokenizer st) {
        String s = st.nextToken().trim();
        if (s == null || s.length() == 0) {
            return (0);
        } else {
            return (Integer.parseInt(s));
        }
    }

    private Time getTime(StringTokenizer st) {
        String s = st.nextToken().trim();
        if (s == null || s.length() == 0) {
            Time t = new Time(0, 0, 0);
            return (t);
        } else {
            // Parse the time in the format 
            // 
            Time t = new Time(0, 0, 0);
            return (t);
        }
    }

    private Time[] parseSplits(StringTokenizer st, int numControls) throws Exception {
        Time splits[] = new Time[numControls + 1];
        String s = st.nextToken().trim();

        if (s.charAt(0) == SPLITS) {
            for (int i = 0; i < numControls; i++) {
                int controlNumber = getInt(st);
                if (i != controlNumber) {
                    throw new Exception("Split times specified out of order");
                }
                int mins = getInt(st);
                int secs = getInt(st);
                splits[i] = new Time(0, mins, secs);
            }
        } else {
            throw new Exception("Splits not found for result");
        }

        return (splits);
    }

    public void loadEvent(URL base, String fileName, boolean urlInput, boolean zipped)
        throws IOException, Exception {

        BufferedReader reader = openReader(base, fileName, urlInput);

        try {

            Course currentCourse = null;
            int numControls = 0;
            String line = " ";

            while (line != null) {

                line = getLine(reader);
                StringTokenizer st = new StringTokenizer(line, ",");

                char lineType = st.nextToken().charAt(0);

                switch (lineType) {
                    case EVENT :
                        break;
                    case CLASS :
                        String classname = getString(st);
                        float length = getFloat(st);
                        String RankingClass = getString(st);
                        numControls = getInt(st);
                        float climb = getFloat(st);

                        currentCourse = new Course(event, classname, numControls);

                        break;
                    case COMPETITOR :
                        if (currentCourse != null) {
                            int position = getInt(st); 
                            String firstName = getString(st);
                            String lastName = getString(st);
                            Time time = getTime(st);
                            String status = getString(st);
                            String club = getString(st);
                            String country = getString(st);
                            String rankingNr = getString(st);
                            String birthYear = getString(st);
                            String birthDate = getString(st);
                            Time startTime = getTime(st);

                            line = getLine(reader);
                            st = new StringTokenizer(line, ",");
                            Time splits[] = parseSplits(st, numControls);

                            Result result = new Result(firstName, lastName, club, currentCourse, startTime, splits);

                            currentCourse.addResult(result);
                            break;
                        } else {
                            throw new Exception("Competitor information found before a course");
                        }
                    case END :
                        continue;

                }
            }
        } catch (Exception e) {
            throw new Exception(
                "Error reading eTiming n3Sport format file "
                    + fileName
                    + " at line "
                    + new Integer(lineCount).toString()
                    + "\n\nError: "
                    + e.toString());
        }
    }

}