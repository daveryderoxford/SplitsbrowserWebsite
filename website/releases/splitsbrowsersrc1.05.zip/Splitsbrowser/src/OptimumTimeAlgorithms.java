/*
 *    SplitsBrowser - Optimum time algorithm classes.
 *
 *    Copyright (C) 2000  Dave Ryder
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this library; see the file COPYING.  If not, write to
 *    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 *    Boston, MA 02111-1307, USA.
 */

//package orienteering.splitsbrowser.model;

import java.util.*;

public class OptimumTimeAlgorithms {
    public interface IOptimumTimeAlgorithm {
        public Time computeTime(Course course, int control);
        public String getName();
        static final int DEFAULT_TIME = 60; 
    }

    public static class Winner implements IOptimumTimeAlgorithm {

        private String name = "Winners time";

        public String getName() {
            return (name);
        }

        public Time computeTime(Course course, int control) {
            /* Return the fastest valid time */
          
            Time time;
            int i=0;
            
            return (course.getWinner().getSplit(control));
            
            /* This code is better but needs some work to 
             * handle 
             * do {
               time = course.getResult(i).getSplit(control);
               i++;
            } while (!time.isValid() && i<course.getNumResults() );
            
            
            // No valid times for the split. 
            if (!time.isValid() ) {
                time = new Time(DEFAULT_TIME);
            }
            
            return (time);*/
        }
    }

    public static class Fastest implements IOptimumTimeAlgorithm {
        private String name = "Fastest split time";

        public String getName() {
            return (name);
        }

        public Time computeTime(Course course, int control) {
            /* Find the fastest split for the leg */

            int IntFastestTime = Integer.MAX_VALUE;

            for (int i = 0; i < course.getNumResults(); i++) {
                Time time = course.getResult(i).getSplit(control);
                if (time.isValid() && time.asSeconds() != 0) {
                    IntFastestTime = Math.min(IntFastestTime, time.asSeconds());
                }
            }

            if (IntFastestTime == Integer.MAX_VALUE) {
                IntFastestTime = DEFAULT_TIME;
            }

            return (new Time(IntFastestTime));
        }
    }

    public static class Comparison implements IOptimumTimeAlgorithm {
        private String name = "Compare with competitor";
        private Result competitor;

        public void setCompetitor(Result newCompetitor) {
            competitor = newCompetitor;
        }

        public String getName() {
            return (name);
        }

        public Time computeTime(Course course, int control) {
            /* Find the fastest split for the leg */
            return (competitor.getSplit(control));
        }
    }

    public static class PercentBehind
        extends Fastest
        implements IOptimumTimeAlgorithm {
        private String name = "Percent behind the best time";
        private int totalPercent = 0;

        public void setPercentBehind(int newPercentBehind) {
            totalPercent = 100 + newPercentBehind;
        }

        public String getName() {
            return (name);
        }

        public Time computeTime(Course course, int control) {
            /* Get the best time from out parent */
            Time time = super.computeTime(course, control);
            int secs = (time.asSeconds() * totalPercent) / 100;
            return (new Time(secs));
        }
    }

    public static Winner winner = new Winner();
    public static Fastest fastest = new Fastest();
    public static Comparison comparison = new Comparison();
    public static PercentBehind percentBehind = new PercentBehind();

}
