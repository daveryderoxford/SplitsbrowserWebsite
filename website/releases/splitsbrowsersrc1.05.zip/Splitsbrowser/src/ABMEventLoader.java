/*
 * SplitsBrowser - ABM format loader.
 *
 * Original Copyright (C) 2002  Gavin Andrews
 *
 * based on Ed Nash's...
 *
 * Version T Copyright (C) 2001 Ed Nash
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.net.URL;
import java.util.Vector;

/**
 */
public class ABMEventLoader extends SIEventLoader {
    static final String[] COURSE_HEADER_PREAMBLE = {
	"Splits", "for", "Course"
    };

    /**
     * A Parser for Gavin Andrews' ABM Results Format
     * based almost entirely on the standard SI Format
     * parser
     *
     * @param newEvent
     *
     */
    public ABMEventLoader(OEvent newEvent) {
	super(newEvent);
    }

    /**
     * Determine course header by looking at fixed text
     * preamble.
     *
     * This would have to get more complex if foreign languages
     * are introduced but it will do for now and would need to
     * change if I add on course length, climb, number of controls
     * to be consistent with the summary page... I need to think
     * about that....
     *
     * @throws java.io.IOException
     *
     */
    protected void courseHeader() throws java.io.IOException {
	if (state == COMPTF || state == INITIAL || state == IGNORE) {
	    int tNum = 0;

	    name = "";

	    // First Check to see if it is an ABM Course Header
	    if (((tokens.size() - 1) >= COURSE_HEADER_PREAMBLE.length)
		    && (typeAt(tokens, 0) == STRING)
		    && (COURSE_HEADER_PREAMBLE[0].equals(stringAt(tokens, 0)))
		    && (typeAt(tokens, 1) == STRING)
		    && (COURSE_HEADER_PREAMBLE[1].equals(stringAt(tokens, 1)))
		    && (typeAt(tokens, 2) == STRING)
		    && (COURSE_HEADER_PREAMBLE[2].equals(stringAt(tokens,
		    2)))) {

		// Skip first 3 Tokens
		tNum = 3;
	    }

	    while ((tNum < tokens.size()) && (typeAt(tokens, tNum) != FLOAT)
		   && (typeAt(tokens, tNum) != NUM_COMPETITORS)) {
		name = name.concat(" ").concat(stringAt(tokens,
							tNum++)).trim();
	    }

	    name = translateChars(name);
	    numControls = 0;
	    state = INFOF;
	} else {
	    formatError("Course Header");
	}
    }

    /**
     * Parse the first row of a course
     * This is the same as the standard SI format but
     * ABM tries to be helpful and puts titles for subsequently
     * columns at the start.  These need to be skipped here and
     * subsequently when parsing splits.  (This is the purpose
     * of the refSkip variable)
     *
     * @throws java.io.IOException
     * @throws java.lang.Exception
     *
     */
    protected void courseInfo()
	    throws java.io.IOException, java.lang.Exception {

	// ABM Changes
	if (state == INFOF || state == INFOC) {
	    int adj = 0;

	    if (state == INFOF) {

		// ABM tries to be helpful by placing labels
		// on the course info record such as "Rank" "Time"
		// which form titles for subsequent rows... we must
		// not interpret these as control records here or
		// subsequently when processing split times.
		refTokens = tokens;
		refSkip = 0;

		for (int i = 0; i < tokens.size(); i++) {
		    if ((typeAt(tokens, i) != CONTROL_CODE)
			    && (typeAt(tokens, i) != FINISH)) {
			refSkip++;
		    } else {
			break;
		    }
		}

		adj = refSkip;
	    }

	    int size = tokens.size();

	    if (typeAt(tokens, size - 1) == FINISH) {
		state = COMPTF;
	    } else {
		state = INFOC;
	    }

	    numControls = numControls + (size - adj);

	    if (state == COMPTF) {
		numControls = numControls - 1;
		course = new Course(event, name, numControls);
	    }
	} else if (state == IGNORE) {}
	else {
	    formatError("Course Info");
	}
    }

    /**
     * Determine line type for specific ABM Course header
     * record and then use superclass function to work out
     * all the rest.  For consistency I keep the old course
     * header check here.
     *
     * @param tokens
     *
     * @return line type
     *
     */
    protected int lineType(Vector tokens) {

	// returns a line type (integer) constant describing the line
	int last = tokens.size() - 1;
	int lastType = typeAt(tokens, last);

	// Determine if it is a ABM Header of the form
	// Splits for Course <courseName>
	if ((lastType == NUM_CONTROLS) || (lastType == KM)) {
	    return COURSE_HEADER;
	}

	if ((last >= COURSE_HEADER_PREAMBLE.length)
		&& (typeAt(tokens, 0) == STRING)
		&& (COURSE_HEADER_PREAMBLE[0].equals(stringAt(tokens, 0)))
		&& (typeAt(tokens, 1) == STRING)
		&& (COURSE_HEADER_PREAMBLE[1].equals(stringAt(tokens, 1)))
		&& (typeAt(tokens, 2) == STRING)
		&& (COURSE_HEADER_PREAMBLE[2].equals(stringAt(tokens, 2)))) {
	    return COURSE_HEADER;
	}

	return super.lineType(tokens);
    }


    protected Token sub(String buffer, int start) {
        int s = start;
        int e;
        String w;
        while (s < buffer.length() && buffer.charAt(s) == ' ')
            s++;
        if (s == buffer.length()) {
            return new Token("", s, STRING);
        }
        e = s;
        while (e < buffer.length() && buffer.charAt(e) != ' ')
            e++;
        start = e;
        w = buffer.substring(s, e);

        // Small ABM Bodge here...  ABM Shows tied rankings in the
        // intelligent way i.e. using say 6= for sixth equal; since
        // this will parse as a STRING rather than an INTEGER we bodge
        // it here... not sure about SI results.. do they really not
        // do this?  If they do then they are probably being missed out

        if ((w.length()>1)&&(w.charAt(w.length()-1) == '='))
          w = w.substring(0, w.length()-1);

        return new Token(w, e, tokenType(w));
    }


}