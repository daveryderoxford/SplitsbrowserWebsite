/*
 *    SplitsBrowser - Result class.
 *
 *    Copyright (C) 2000  Dave Ryder
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this library; see the file COPYING.  If not, write to
 *    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 *    Boston, MA 02111-1307, USA.
 */

//package orienteering.splitsbrowser.model;

import java.lang.*;
import java.util.*;
import java.awt.event.*;
import java.io.Serializable;

/**
 * Encapsulates an orienteering result.
 *
 * @author <b>Dave Ryder</b>
 * @version 1.0
 */
public class Result extends Object implements Serializable
{
	public Result() {}

	/** Create a result specifying the start time.
	*
		 * @param newCourse Course the result is part of
		 * @param newStartTime Comprtitors start time
		 * @param splits split times
		 */
	private Result(Course newCourse,
		 Time newStartTime,
		 Time[] splits)
	{
		course       = newCourse;
		splitTimes   = splits;
		startTime    = newStartTime;
		elaspedTimes = null;
		positions = new int[course.getNumSplits()];
		course.addResult(this);
	}

	/** Create a result specifying the start time
	*
		 * @param newFirstName Given name of the competitor
		 * @param newSurname Family name of the competitor
		 * @param newClub Competitor's club
		 * @param newCourse Course the result is part of
		 * @param newStartTime Comprtitors start time
		 * @param splits Array of split times
		 * @param splits split times
		 * @param splits split times
		 */
	public Result(String newFirstName,
		String newSurname,
		String newClub,
		Course newCourse,
		Time newStartTime,
		Time[] splits)
	{
		this(newCourse, newStartTime, splits);
		setFirstName(newFirstName);
		setSurname(newSurname);
		setClub(newClub);
	}

	/** Sets the given name for a result
	*
		 * @param newFirstName Given name of the competitor
		 */
	public void setFirstName(String newFirstName)
	{
		firstName = newFirstName;
		fullName = firstName + " " + surname; //$NON-NLS-1$
	}

	/** Gets the given name for a result
		 */
	public String getFirstName()
	{
		return firstName;
	}

	/** Sets the surname name for a result
	*
		 * @param newSurname Family name of the competitor
		 */
	public void setSurname(String newSurname)
	{
		surname = newSurname;
		fullName = firstName + " " + surname; //$NON-NLS-1$
	}

	/** Gets the family name for a result
		 */
	public String getSurname()
	{
		return surname;
	}

	/** Sets the club name for a result
	*
		 * @param newClub Club for the result
		 */
	public void setClub(String newClub)
	{
		club = newClub;
	}

	public String getClub()
	{
		return club;
	}

	/** Gets the total time the competitor took
		 */
	public Time getTotalTime()
	{
		return getElaspsed( course.getNumSplits()-1 );
	}

	/** Gets the split time for a given control
		 */
	public Time getSplit(int i)
	{
		return splitTimes[i];
	}

	/** Gets the elapsed time for a given control
	*/
	public Time getElaspsed(int i){
		if (elaspedTimes == null){
			 /* Create array for the elapsed times */
			 elaspedTimes = new Time[course.getNumSplits()];

			 /* Compute the elasped times */
			 int sum = 0;
			 int maxi=course.getNumSplits();
			 for (int iCount=0;iCount <maxi;iCount++){
				sum = sum + splitTimes[iCount].asSeconds();
				elaspedTimes[iCount] = new Time(sum,splitTimes[iCount].isValid());
			 }
		 }
		 return(elaspedTimes[i]);
	}

	/** Copmputes the time loss for all the splits
	*
	* The algorithm used to calculate the time loss
	* assumes that the competitor travels at a relatively constant
	* rate except for the occasional mistake.
	*
	* This constant rate is calculated by ignoring the N worst controls
	* (where N is dependent on the number of controls on the course) and using this to
	* calculate a loss rate against the optimum time.
	*
	* This rate is then used to calculate an expected time for the leg which is
	* compared against the optimum time.
	*
	*/
	protected void computeTimeLosses()
	{
		int numWorstTimes;

		if (course.getNumControls() < 10) {
			 numWorstTimes = 2;
		} else if (course.getNumControls() < 15) {
			 numWorstTimes = 3;
		} else {
			 numWorstTimes = 4;
		}

		double[] worstLosses = {-1000,-1000,-1000,-1000};
		int[] worstSplits = {-1,-1,-1,-1};

		/* First find the mistakes that we will ignore in computing how fast our man should go */
		for (int splitCount=0;  splitCount< course.getNumSplits(); splitCount++) {
			for (int i=0; i<numWorstTimes; i++) {

	double lossRate = getSplit(i).asSeconds() / course.getOptimumTime(splitCount).asSeconds();

	if (lossRate > worstLosses[i]) {
		worstLosses[i] = lossRate;
		worstSplits[i] = i;
		break;
	}
			}
		}

		// Subtract the worst splits from the total time to get his loss rate
		int total = getTotalTime().asSeconds();
		int totalOptimum = course.getOptimumTime( course.getNumSplits() ).asSeconds();

		for (int i=0; i<numWorstTimes; i++) {
			total = total - getSplit(worstSplits[i]).asSeconds();
			totalOptimum = totalOptimum - course.getOptimumTime(worstSplits[i]).asSeconds();
		}

		double lossRate = total / totalOptimum;

		// Finally calculate the time loss for each leg
		for (int i=0;  i<course.getNumSplits(); i++) {
			int expectedTime =  new Double(getSplit(i).asSeconds() * lossRate).intValue();
			timeLoss[i] = new Time(expectedTime - course.getOptimumTime(i).asSeconds());
		}
	}

	/** Gets the time loss for a given split.<BR>
	*
	* The time loss is compared against the optimum time and
	* assumes that the competitor is traveling at a constant
	* rate except for the occasional mistake.
	*
		 * @param split Chosen split
		 */
	public Time getTimeLoss(int split)
	{
		if (timeLoss == null)
		{
			timeLoss = new Time[course.getNumSplits()];
			computeTimeLosses();
		}
		return( timeLoss[split] );
	}

	public Time getTimeBehindOptimum(int split)
	{
		 Time t = new Time(getSplit(split).asSeconds() -
			course.getOptimumTime(split).asSeconds());
		 return (t);
	}

	/** Gets the actual time to reach a given split.
	*
		 * @param split Chosen split
		 */
	public Time getActualTime(int split)
	{
		int seconds = startTime.asSeconds() +
					getElaspsed(split).asSeconds();
			return( new Time(seconds));
	}

	/** Gets the start time
		 */
	public Time getStartTime()
	{
		return startTime;
	}

	/** Gets the overall finish position
		 */
	public int getPosition()
	{
		return course.getPosition(this);
	}

	/** Gets the position for a given split
	*
		 * @param split Chosen split
		 */
	public int getSplitPosition(int split)
	{
		 return( positions[split] );
	}

	/* Used by course to set the position */
	void setPosition(int split, int newPosition)
	{
		positions[split] = newPosition;
	}

	/** Gets competitor's full name
		 */
	public String getFullName()
	{
		return fullName;
	}

	/** Gets competitor's and finish time formatted as string
		 */
	public String getNameAndTime()
	{
		return fullName + "  " + getTotalTime().toString() ; //$NON-NLS-1$
	}

	private String firstName;
	private String surname;
	private String fullName;
	private String club;
	private Course course;
	private Time startTime  = null;

	private Time[] splitTimes = null;
	private int[] positions   = null;
	private transient Time[] elaspedTimes = null;
	private transient Time[] timeLoss = null;
}
