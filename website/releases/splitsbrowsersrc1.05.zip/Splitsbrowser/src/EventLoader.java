/*
 *    SplitsBrowser - EventLoader.
 *
 *    Copyright (C) 2000  Dave Ryder
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this library; see the file COPYING.  If not, write to
 *    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 *    Boston, MA 02111-1307, USA.
 */

import java.io.*;
import java.util.*;
import java.net.*;
import java.util.zip.*;

import sun.misc.UCDecoder;

/**
 * Loads a single course from a CVS file.
 * The format of the data is
 * CourseName,NumControls
 * FristName, LastName, Club, StartHour:StartMins,
 * Split1Mins:Splits1Sec,....Numcontrols+1 times
 *
 * Each class is terminated by a blank line and the file terminated by two blank lines or
 * the end of the file
 *
 * @author <b>Dave Ryder</b>
 * @version 1.0
 */
public class EventLoader {
    public EventLoader() {}

    public EventLoader(OEvent newEvent) {
        event = newEvent;
    }

    private boolean notBlank(String line) {
        return ((line != null) && (line.trim().length() != 0));
    }

    public void loadEvent(URL base, String fileName, boolean urlInput)
        throws IOException, Exception {
        BufferedReader reader = openReader(base, fileName, urlInput);

        // Read course info
        int lineCount = 0;
        try {

            lineCount++;
            String line = reader.readLine();

            while (notBlank(line)) {

                StringTokenizer st = new StringTokenizer(line, ",:"); //$NON-NLS-1$
                String name = new String(st.nextToken());
                int numControls = Integer.parseInt(st.nextToken().trim());

                Course course = new Course(event, name, numControls);

                // Read results until a blank line
                lineCount++;
                line = reader.readLine();

                while (notBlank(line)) {
                    // Read the result
                    st = new StringTokenizer(line, ",:"); //$NON-NLS-1$

                    // Parse the data
                    String firstName = st.nextToken();
                    String surname = st.nextToken();
                    String club = st.nextToken();
                    String startHour = st.nextToken();
                    String startMin = st.nextToken();

                    // Time startTime = new Time(startHour, startMin, 0);
                    Time startTime = new Time(0, 0, 0);

                    /* Read the splits data */
                    Time splits[] = new Time[numControls + 1];
                    int mins;
                    int secs;

                    for (int i = 0; i < numControls + 1; i++) {
                        mins = Integer.parseInt(st.nextToken().trim());
                        if ((mins < 0)) {
                            throw new Exception(
                                Messages.getString("EventLoader.Invalid_minutes_in_file") + fileName + Messages.getString("EventLoader._result_for__4") + surname + Messages.getString("EventLoader.__value__5") + mins); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                        }

                        secs = Integer.parseInt(st.nextToken().trim());
                        if ((secs < 0) || (secs > 59)) {
                            throw new Exception(
                                Messages.getString("EventLoader.Invalid_seconds_in_file__6") + fileName + Messages.getString("EventLoader._result_for__7") + surname + Messages.getString("EventLoader.__value__8") + secs); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                        }
                        splits[i] = new Time(mins, secs);
                    }

                    // ... and create the result
                    Result result = new Result(firstName, surname, club, course, startTime, splits);

                    // Read the next results line
                    lineCount++;
                    line = reader.readLine();
                }
                // Read next class line
                lineCount++;
                line = reader.readLine();
            }
        } catch (Exception e) {
            throw new Exception(
                Messages.getString("EventLoader.Error_reading_CVS_format_file__9") //$NON-NLS-1$
                    + fileName
                    + Messages.getString("EventLoader._at_line__10") //$NON-NLS-1$
                    + new Integer(lineCount).toString()
                    + Messages.getString("EventLoader._n_nError___11") //$NON-NLS-1$
                    + e.toString());
        }
    }

    private String getExtension(String fileName) {
                       
        int i = fileName.lastIndexOf('.');
        if (1 > 0 && i < fileName.length() - 1) {
            return fileName.substring(i+1).toLowerCase();
        } else {
            return ""; //$NON-NLS-1$
        }
    }

    protected BufferedReader openReader(URL base, String fileName, boolean urlInput)
        throws IOException, Exception {
        InputStream inputStream;
        BufferedReader reader;

        try {
            if (urlInput) {
                URL myURL = new URL(base, fileName);
                DataInputStream stream = new DataInputStream(myURL.openStream());
                inputStream = stream;

            } else {
                FileInputStream stream = new FileInputStream(fileName);
                inputStream = stream;
            }
            
           String extension = getExtension(fileName);
            
           if (extension.equals("zip")) { //$NON-NLS-1$
                ZipInputStream zippedStream = new ZipInputStream(inputStream);
                // Move to the first file entry
                ZipEntry entry = zippedStream.getNextEntry();
                reader = new BufferedReader(new InputStreamReader(zippedStream));
            } else if (extension.equals("gz")) { //$NON-NLS-1$
                GZIPInputStream zippedStream = new GZIPInputStream(inputStream);
                reader = new BufferedReader(new InputStreamReader(zippedStream));
            } else if (extension.startsWith("php")) { //$NON-NLS-1$
                GZIPInputStream zippedStream = new GZIPInputStream(inputStream);
                reader = new BufferedReader(new InputStreamReader(zippedStream));
            } else {
                reader = new BufferedReader(new InputStreamReader(inputStream));
            } 

        } catch (Exception e) {
            throw (new IOException(Messages.getString("EventLoader.Error_encountered_opening_file__16") + fileName)); //$NON-NLS-1$
        }

        return (reader);
    }

    protected OEvent event;
}