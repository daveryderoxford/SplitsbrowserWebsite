/**
 * @version 	1.0
 * @author
 */
public class Run {


        public static void main(String[] args) {
            sun.applet.AppletViewer.main(new String[] { 
                                 "./tests/example.html" });
        }     

}