/*
 *    SplitsBrowser - SplitsTable class.
 *
 *    Copyright (C) 2000  Dave Ryder
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Library General Public
 *    License as published by the Free Software Foundation; either
 *    version 2 of the License, or (at your option) any later version.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Library General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this library; see the file COPYING.  If not, write to
 *    the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 *    Boston, MA 02111-1307, USA.
 */

import java.awt.*;

/**
 * A scrolling panel which displays a simple text vie wof split results
 *
 * @author <b>Dave Ryder</b>
 * @version 1.0
 */
public class SplitsTable extends TextArea {
    BorderLayout borderLayout1 = new BorderLayout();
    private Course course;
    private boolean courseInvalid = true;
    private boolean showCumulative;
    private boolean showComparison;
    private boolean showPositions;

    protected int CONTROL_REQ = 5;
    protected String CONTROL_GAP = "  "; //$NON-NLS-1$
    protected int CONTROL_COLS = CONTROL_REQ + CONTROL_GAP.length();

    protected String NAME_PADDING = "                   "; //$NON-NLS-1$
    protected String POS_PADDING = "     "; //$NON-NLS-1$
    protected String TITLE_PADDING = POS_PADDING + NAME_PADDING + "       "; //$NON-NLS-1$
    protected int TITLE_COLS = TITLE_PADDING.length();
    private boolean showSplits = true;

    public SplitsTable() {
        try {
            jbInit();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        this.setSize(new Dimension(403, 291));
        // A fixed width font must be used in this control
        this.setFont(new Font("Courier", 0, 11)); //$NON-NLS-1$
        this.setBackground(Color.white);
        this.setEditable(false);
    }

    public void setCourse(Course newCourse) {
        course = newCourse;
        // delay setting the text until it is first shown
        courseInvalid = true;
        repaint();
    }

    public void setShowSplits(boolean newShowSplits) {
        showSplits = newShowSplits;
        courseInvalid = true;
        repaint();
    }

    protected void drawCourse() {
        if (course != null) {
            setCols();
            setRows();
            setCourseText();
        }
    }

    public void paint(Graphics g) {
        if (courseInvalid) {
            drawCourse();
            courseInvalid = false;
        }
        super.paint(g);
    }

    protected void setCols() {
        int numCols = course.getNumSplits() * CONTROL_COLS + TITLE_COLS;

        this.setColumns(numCols);
    }

    protected int rowsPerResult() {
        int rowsPerResult = 3;

        if (isShowCumulative()) {
            rowsPerResult = rowsPerResult + 1;
        }

        if (isShowComparison()) {
            rowsPerResult = rowsPerResult + 1;
        }

        if (isShowPositions()) {
            rowsPerResult = rowsPerResult + 1;
        }

        return (rowsPerResult);

    }

    private void setRows() {
        int rows = course.getNumResults() * rowsPerResult();
        this.setRows(rows);
    }

    private String leftPad(String value, int len) {
        String s = value;
        while (len > s.length()) {
            s = " " + s; //$NON-NLS-1$
        }
        return (s);
    }

    protected void setCourseText() {

        StringBuffer s = new StringBuffer(getColumns() * getRows());

        StringBuffer emptyBuf = new StringBuffer(getColumns());
        for (int i = 0; i < getColumns(); i++) {
            emptyBuf.append(" "); //$NON-NLS-1$
        }
        String emptyLine = emptyBuf.toString();

        for (int res = 0; res < course.getNumResults(); res++) {

            // Top line has name and split times
            Result result = course.getResult(res);

            String name = result.getFullName();

            s.append(leftPad(Integer.toString(res + 1), 3) + "  "); //$NON-NLS-1$

            if (name.length() > NAME_PADDING.length()) {
                // String is longer than max - truncate
                name = name.substring(0, NAME_PADDING.length());
                s.append(name);
            } else {
                // String is less then max - pad
                s.append(name);
                int padlen = NAME_PADDING.length() - name.length();
                for (int i = 0; i < padlen; i++) {
                    s.append(" "); //$NON-NLS-1$
                }
            }

            s.append(" " + leftPad(result.getTotalTime().toString(), 6)); //$NON-NLS-1$

            // Write the total times
            for (int iSplit = 0; iSplit < course.getNumSplits(); iSplit++) {
                if (result.getElaspsed(iSplit).getMins() < 100) {
                    s.append(CONTROL_GAP + " " + result.getElaspsed(iSplit).toString()); //$NON-NLS-1$
                } else {
                    s.append(CONTROL_GAP + result.getElaspsed(iSplit).toString());
                }

            }
            s.append("     \n"); //$NON-NLS-1$

            // If splits required write the split times
            if (showSplits) {
                s.append(TITLE_PADDING);
                for (int iSplit = 0; iSplit < course.getNumSplits(); iSplit++) {
                    if (result.getSplit(iSplit).getMins() < 100) {
                        s.append(CONTROL_GAP + " " + result.getSplit(iSplit).toString()); //$NON-NLS-1$
                    } else {
                        s.append(CONTROL_GAP + result.getSplit(iSplit).toString());
                    }
                }
                s.append("     \n"); //$NON-NLS-1$
            }
            s.append(emptyLine + "\n"); //$NON-NLS-1$
        }
        setText(s.toString());
    }

    public Course getCourse() {
        return course;
    }

    public void setShowCumulative(boolean newShowCumulative) {
        if (showCumulative != newShowCumulative) {
            showCumulative = newShowCumulative;
            setCourseText();
        }
    }

    public boolean isShowCumulative() {
        return showCumulative;
    }

    public void setShowComparison(boolean newShowComparison) {
        if (showComparison != newShowComparison) {
            showComparison = newShowComparison;
            setCourseText();
        }
    }

    public boolean isShowComparison() {
        return showComparison;
    }

    public void setShowPositions(boolean newShowPositions) {
        if (showPositions != newShowPositions) {
            showPositions = newShowPositions;
            setCourseText();
        }
    }

    public boolean isShowPositions() {
        return showPositions;
    }

}